import { Component, OnInit } from '@angular/core';
import { InvantoryService } from '../invantory.service';
import { NavController } from '@ionic/angular';
import { ToastController } from '@ionic/angular';
import { TransformVisitor } from '@angular/compiler/src/render3/r3_ast';
import { Router } from '@angular/router';

@Component({
  selector: 'app-edit-produce-iteam',
  templateUrl: './edit-produce-iteam.page.html',
  styleUrls: ['./edit-produce-iteam.page.scss'],
})
export class EditProduceIteamPage implements OnInit {
  AllPeoducationData;
  ids; nane;  type; quntity;
  unit;  amount;  Date;
  constructor(private Storage :InvantoryService,private nvert :Router,public toastController: ToastController) { 
  this.AllPeoducationData = this.Storage.RrturnEditDara();
  this.ids = this.AllPeoducationData.id;
    this.nane = this.AllPeoducationData.productname;
    this.type = this.AllPeoducationData.producttype;
    this.quntity = this.AllPeoducationData.quantity;
    this.unit = this.AllPeoducationData.unit;
    this.amount = this.AllPeoducationData.amount;
    this.Date = this.AllPeoducationData.date;
  }
  Pquantity;
  Pamount;
  async  Edit_producation(productname,producttype,quantity,unit,amount,date){
    this.Pquantity = parseInt(quantity);
    this.Pamount = parseInt(amount);

    if(!productname){
      const toast = await this.toastController.create({
        message: 'Please Enter Product Name',
        duration: 2000
      });
      toast.present();
    }else if(!producttype){
      const toast = await this.toastController.create({
        message: 'Please Enter Product Type',
        duration: 2000
      });
      toast.present();
    }else if(!quantity){
      const toast = await this.toastController.create({
        message: 'Please Enter Product Quantity',
        duration: 2000
      });
      toast.present();
    }else if(!unit){
      const toast = await this.toastController.create({
        message: 'Please Enter Product Unit',
        duration: 2000
      });
      toast.present();
    }else if(!amount){
      const toast = await this.toastController.create({
        message: 'Please Enter Product Amount',
        duration: 2000
      });
      toast.present();
    }else if(!date){
      const toast = await this.toastController.create({
        message: 'Please Enter Product Date',
        duration: 2000
      });
      toast.present();
    }else{
      if(this.Pquantity>0){

        if(this.Pamount>0){
          var id = this.ids;
          this.Storage.Update_producation(this.AllPeoducationData,id,productname,producttype,this.Pquantity,unit,this.Pamount,date).then( (data) => {  
          console.log("Done"+data);
          this.nvert.navigate(['/produce-iteam-list']);
        },(error) =>{ 
         console.log("Erroe"+error);
      })
      }else{
          const toast = await this.toastController.create({
            message: 'Please Enter Valid Amount',
            duration: 2000
          });
          toast.present();
        }
      }else{
        const toast = await this.toastController.create({
          message: 'Please Enter Valid Quantity',
          duration: 2000
        });
        toast.present();
      }
    }   
  }
  UnitList:any;
ionViewWillEnter(){
  this.Storage.Show_Unit().then((data: any) => {
    console.log(data);
    this.UnitList = data;
  }, (error) => {
    console.log(error);
  })
   }
nevroot(){
  this.nvert.navigate(['/home']);
}
  ngOnInit() {
  }

}
