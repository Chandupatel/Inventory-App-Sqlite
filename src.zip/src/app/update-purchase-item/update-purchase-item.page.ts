import { Component, OnInit } from '@angular/core';
import { NavController, ToastController } from '@ionic/angular';
import { InvantoryService } from '../invantory.service';
import { Route, Router } from '@angular/router';

@Component({
  selector: 'app-update-purchase-item',
  templateUrl: './update-purchase-item.page.html',
  styleUrls: ['./update-purchase-item.page.scss'],
})
export class UpdatePurchaseItemPage implements OnInit {
  updateddata;
  idf;
  cname;
  ctype;
  cproviderdetails;
  cquantity;
  cunit;
  ctotalamount;
  cpaidamount;
  cdate;
  cdetails;
  productname:string;
producttype:string;
providerdetails:string;
quantity:string;
unit:string;
totalamount:string;
paidamount:string;
date:string;
details:string; 
  status:boolean;
  status1:boolean;
  status2:boolean;
stat1:boolean;

  constructor(private Storage :InvantoryService,private navcrt :NavController,public toastController: ToastController,private r:Router)
   { 
    this.updateddata = this.Storage.Returnupdatedata();
    this.idf = this.updateddata.id;
    this.cname = this.updateddata.productname;
    this.ctype = this.updateddata.producttype;
    this.cproviderdetails = this.updateddata.providerdetails;
    this.cquantity = this.updateddata.quantity;
    this.cunit = this.updateddata.unit;
    this.ctotalamount = this.updateddata.totalamount;
    this.cpaidamount = this.updateddata.paidamount;
    this.cdate = this.updateddata.date;
    this.cdetails =this.updateddata.details;
    console.log(this.cpaidamount);
    console.log(this.ctotalamount);
  }
  display(){
      console.log(this.ctotalamount);
      console.log(this.cpaidamount);
    if(this.ctotalamount==this.cpaidamount){
      this.status=true;
      this.status1=false;
      this.status2=false;
     // this.checked=true;
      this.stat1=false;
    } 
    else if(this.ctotalamount>this.cpaidamount && this.cpaidamount!==0 && this.cpaidamount>=0 && this.cpaidamount!==null){
         this.status1=true;
         this.status=false;
         this.status2=false;
        // this.checked=true;
        this.stat1=true;
        }
      
          else if(this.cpaidamount>this.ctotalamount){
           alert("Invalid entry");
           this.status2=false;
            this.status1=false;
            this.status=false;
           // this.checked=true;
            this.stat1=false;
          }
          else{
            this.status2=true;
            this.status1=false;
            this.status=false;
           // this.checked=true;
            this.stat1=true;
          }
  }
  pquan;
  ptotal;
  ppaid;

  async updateitem(){
    console.log(this.cname,this.ctype,this.cproviderdetails,this.cquantity,this.cunit,this.ctotalamount,this.cpaidamount,this.idf);
    this.productname=this.cname;
    this.producttype=this.ctype;
    this.providerdetails=this.cproviderdetails;
    this.quantity=this.cquantity;
    this.unit=this.cunit;
    this.totalamount=this.ctotalamount;
    this.paidamount=this.cpaidamount;
    this.date=this.cdate;
    this.details=this.cdetails;

   this.pquan= parseInt(this.quantity);
   this.ptotal= parseInt(this.totalamount);
   this.ppaid= parseInt(this.paidamount);


   if(!this.productname){
    const toast = await this.toastController.create({
      message: 'Please Enter Product Name',
      duration: 2000
    });
    toast.present();
  }else if(!this.producttype){
    const toast = await this.toastController.create({
      message: 'Please Enter Product Type',
      duration: 2000
    });
    toast.present();
  }else if(!this.providerdetails){
    const toast = await this.toastController.create({
      message: 'Please Enter Provider Details',
      duration: 2000
    });
    toast.present();
  }
    else if(!this.quantity){
      const toast = await this.toastController.create({
        message: 'Please Enter Product Quantity',
        duration: 2000
      });
      toast.present();
  }else if(!this.unit){
    const toast = await this.toastController.create({
      message: 'Please Select Unit',
      duration: 2000
    });
    toast.present();
  }else if(!this.totalamount){
    const toast = await this.toastController.create({
      message: 'Please Enter Total Amount',
      duration: 2000
    });
    toast.present();
  }
  else if(!this.date){
    const toast = await this.toastController.create({
      message: 'Please Enter Product Date',
      duration: 2000
    });
    toast.present();
  }else{
    if(this.pquan>0 && this.ptotal>0 &&this.ppaid>=0)
{
      if(this.ptotal == this.ppaid )
    {
   if(!this.productname|| !this.producttype || !this.providerdetails || !this.quantity  || !this.unit || !this.totalamount || !this.paidamount ||!this.date)
   {   
     /* alert("please enter the valid details"); */
     const toast = await this.toastController.create({
       message: 'Please Enter All The Details',
       duration: 2000
     });
     toast.present();
   }
    else{
      this.Storage.Update_Purchase(this.updateddata,this.productname,this.producttype,this.providerdetails,this.quantity,this.unit,this.totalamount,this.paidamount,this.date,this.details,this.idf).then( (data) => {
        console.log("tsfiledatre"+this.date);
        console.log(data);
        this.r.navigate(['/purchaseitem']);
      },(error) =>{
       
       console.log(error);
    })
   }
  
 }
  else {
  if(this.ptotal < this.ppaid || this.ppaid > 0){
   if(!this.productname|| !this.producttype || !this.providerdetails || !this.quantity  || !this.unit || !this.totalamount || !this.paidamount ||!this.date ||!this.details)
   {   
     /* alert("please enter the valid details"); */
     const toast = await this.toastController.create({
       message: 'Please Enter All The Details',
       duration: 2000
     });
     toast.present();
   }
    else{
      this.Storage.Update_Purchase(this.updateddata,this.productname,this.producttype,this.providerdetails,this.quantity,this.unit,this.totalamount,this.paidamount,this.date,this.details,this.idf).then( (data) => {
        console.log("tsfiledatre"+this.date);
        console.log(data);
        this.r.navigate(['/purchaseitem']);
      },(error) =>{
       
       console.log(error);
    })
   }
  
 }
 else{
   if(!this.productname|| !this.producttype || !this.providerdetails || !this.quantity  || !this.unit || !this.totalamount ||!this.date ||!this.details)
   {   
     /* alert("please enter the valid details"); */
     const toast = await this.toastController.create({
       message: 'Please Enter All The Details',
       duration: 2000
     });
     toast.present();
   }
    else{
      this.Storage.Update_Purchase(this.updateddata,this.productname,this.producttype,this.providerdetails,this.quantity,this.unit,this.totalamount,this.paidamount,this.date,this.details,this.idf).then( (data) => {
       console.log("tsfiledatre"+this.date);
        console.log(data);
        this.r.navigate(['/purchaseitem']);
      },(error) =>{
       
       console.log(error);
    })
   }
 }
 }
 }
else{
  const toast = await this.toastController.create({
    message: 'Please Enter Valid Quantity OR Total Amount OR Paid Amount',
    duration: 2000
  });
  toast.present();
}
}
  }
  UnitList:any;
ionViewWillEnter(){
  this.Storage.Show_Unit().then((data: any) => {
    console.log(data);
    this.UnitList = data;
  }, (error) => {
    console.log(error);
  })
   }
  ngOnInit() {
  }   
}