import { Component, OnInit } from '@angular/core';
import { InvantoryService } from '../invantory.service';
import { checkAndUpdateDirectiveDynamic } from '@angular/core/src/view/provider';
import { ToastController } from '@ionic/angular';
import { Router } from '@angular/router';
@Component({
  selector: 'app-add-purchase-item',
  templateUrl: './add-purchase-item.page.html',
  styleUrls: ['./add-purchase-item.page.scss'],
})

export class AddPurchaseItemPage implements OnInit {
  constructor(private storage:InvantoryService,public toastController: ToastController,private r:Router) {}
  productname:string;
  producttype:string;
  providerdetails:string;
  quantity:string;
  unit:string;
  totalamount:string;
  paidamount:string;
  date:string;
  details:string;
  status:boolean;
  status1:boolean;
  status2:boolean;
  stat1:boolean;
  
  n = new Date();
  y = this.n.getFullYear();
  m = this.n.getMonth()+1;
  d = this.n.getDate();
 
 mon  = this.m.toString();
 month  = parseInt(this.mon); 
 
 da;


  display(){
    this.pquan= parseInt(this.quantity);
     this.ptotal= parseInt(this.totalamount);
     this.ppaid= parseInt(this.paidamount);
    if(this.ptotal==this.ppaid){
      this.status=true;
      this.status1=false;
      this.status2=false;
     // this.checked=true;
      this.stat1=false;
    } 
        else if(this.ptotal>this.ppaid && this.ppaid!==0 && this.ppaid>=0 && this.ppaid!==null){
         this.status1=true;
         this.status=false;
         this.status2=false;
        // this.checked=true;
        this.stat1=true;
        }
          else if(this.ppaid>this.ptotal){
           alert("Invalid entry");
           this.status2=false;
            this.status1=false;
            this.status=false;
           // this.checked=true;
            this.stat1=false;
          }
          else{
            this.status2=true;
            this.status1=false;
            this.status=false;
           // this.checked=true;
            this.stat1=true;
          }
  }
  pquan;
  ptotal;
  ppaid;
   async addpurchase(){
     this.pquan= parseInt(this.quantity);
     this.ptotal= parseInt(this.totalamount);
     this.ppaid= parseInt(this.paidamount);
     if(this.month < 10){
      this.da = this.y+"-0"+this.m+"-"+this.d;
    }else{
     this.da = this.y+"-"+this.m+"-"+this.d;
    }
     if(!this.productname){
      const toast = await this.toastController.create({
        message: 'Please Enter Product Name',
        duration: 2000
      });
      toast.present();
    }else if(!this.producttype){
      const toast = await this.toastController.create({
        message: 'Please Enter Product Type',
        duration: 2000
      });
      toast.present();
    }else if(!this.providerdetails){
      const toast = await this.toastController.create({
        message: 'Please Enter Provider Details',
        duration: 2000
      });
      toast.present();
    }
      else if(!this.quantity){
        const toast = await this.toastController.create({
          message: 'Please Enter Product Quantity',
          duration: 2000
        });
        toast.present();
    }else if(!this.unit){
      const toast = await this.toastController.create({
        message: 'Please Select Unit',
        duration: 2000
      });
      toast.present();
    }else if(!this.totalamount){
      const toast = await this.toastController.create({
        message: 'Please Enter Total Amount',
        duration: 2000
      });
      toast.present();
    }
    else if(!this.date){
      const toast = await this.toastController.create({
        message: 'Please Enter Product Date',
        duration: 2000
      });
      toast.present();
    }else{
      if(this.date == this.da){
      if(this.pquan>0 && this.ptotal>0 &&this.ppaid>=0)
    {
     if(this.ptotal == this.ppaid )
     {
    if(!this.productname|| !this.producttype || !this.providerdetails || !this.quantity  || !this.unit || !this.totalamount || !this.paidamount ||!this.date)
    {   
      /* alert("please enter the valid details"); */
      const toast = await this.toastController.create({
        message: 'Please Enter All The Details',
        duration: 2000
      });
      toast.present();
    }
     else{
       this.storage.CreateUser1(this.productname,this.producttype,this.providerdetails,this.quantity,this.unit,this.totalamount,this.paidamount,this.date,this.details).then( (data) => {
        console.log("hi");
         console.log(data);
         this.r.navigate(['/purchaseitem']);
       },(error) =>{
        
        console.log(error);
     })
    }
   
  }
   else{ 
   if(this.ptotal < this.ppaid || this.ppaid>0){
    if(!this.productname|| !this.producttype || !this.providerdetails || !this.quantity  || !this.unit || !this.totalamount || !this.paidamount ||!this.date ||!this.details)
    {   
      /* alert("please enter the valid details"); */
      const toast = await this.toastController.create({
        message: 'Please Enter  The Details',
        duration: 2000
      });
      toast.present();
    }
     else{
       this.storage.CreateUser1(this.productname,this.producttype,this.providerdetails,this.quantity,this.unit,this.totalamount,this.paidamount,this.date,this.details).then( (data) => {
        console.log("hi");
         console.log(data);
         this.r.navigate(['/purchaseitem']);
       },(error) =>{
        
        console.log(error);
     })
    }
   
  }
  else{
    if(!this.productname|| !this.producttype || !this.providerdetails || !this.quantity  || !this.unit || !this.totalamount ||!this.date ||!this.details)
    {   
      /* alert("please enter the valid details"); */
      const toast = await this.toastController.create({
        message: 'Please Enter The Details',
        duration: 2000
      });
      toast.present();
    }
     else{
       this.storage.CreateUser1(this.productname,this.producttype,this.providerdetails,this.quantity,this.unit,this.totalamount,this.paidamount,this.date,this.details).then( (data) => {
        console.log("hi");
         console.log(data);
         this.r.navigate(['/purchaseitem']);
       },(error) =>{
        
        console.log(error);
     })
    }
   
  }
  }
}
  else{
    const toast = await this.toastController.create({
      message: 'Please Enter Valid Quantity OR Total Amount OR Paid Amount',
      duration: 2000
    });
    toast.present();
  }
}else{
  const toast = await this.toastController.create({
    message: 'Please Select Current Date',
    duration: 2000
  });
  toast.present();
}
}
  }
  UnitList:any;
ionViewWillEnter(){
  this.storage.Show_Unit().then((data: any) => {
    console.log(data);
    this.UnitList = data;
  }, (error) => {
    console.log(error);
  })
   }
  
  
    ngOnInit() {
    }
    }
  
  
  