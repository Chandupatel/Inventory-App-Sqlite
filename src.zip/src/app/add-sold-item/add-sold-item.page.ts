import { Component, OnInit } from '@angular/core';
import { InvantoryService } from '../invantory.service';
import { ToastController } from '@ionic/angular';
import { Router } from '@angular/router';
@Component({
  selector: 'app-add-sold-item',
  templateUrl: './add-sold-item.page.html',
  styleUrls: ['./add-sold-item.page.scss'],
})
export class AddSoldItemPage implements OnInit {
  constructor(private storage:InvantoryService,private toastController:ToastController,private r:Router) { }
//   productname:string;
// customername:string;
// quantity:string;
// unit:string;
// totalamount:string;
// paidamount:string;
// date:string;
// customerdetails:string;
// status:boolean;
//   status1:boolean;
//   status2:boolean;
// stat1:boolean;
// 
// pquan;
// ptotal;
// ppaid;
// n = new Date();
// y = this.n.getFullYear();
// m = this.n.getMonth()+1;
// d = this.n.getDate();

// mon  = this.m.toString();
// month  = parseInt(this.mon); 

// da;

// display(){
//   this.pquan= parseInt(this.quantity);
//    this.ptotal= parseInt(this.totalamount);
//    this.ppaid= parseInt(this.paidamount);
//   if(this.ptotal==this.ppaid){
//     this.status=true;
//     this.status1=false;
//     this.status2=false;
//    // this.checked=true;
//     this.stat1=false;
  
//   } 

//       else if(this.ptotal>this.ppaid && this.ppaid!==0 && this.ppaid>=0 && this.ppaid!==null){
//        this.status1=true;
//        this.status=false;
//        this.status2=false;
//       // this.checked=true;
//       this.stat1=true;
//       }
    
//         else if(this.ppaid>this.ptotal){
//          alert("Invalid entry");
//          this.status2=false;
//             this.status1=false;
//             this.status=false;
//            // this.checked=true;
//             this.stat1=false;
//         }
//         else{
//           this.status2=true;
//           this.status1=false;
//           this.status=false;
//          // this.checked=true;
//           this.stat1=true;
//         }
// }
// async addsold(){
//   this.pquan= parseInt(this.quantity);
//    this.ptotal= parseInt(this.totalamount);
//    this.ppaid= parseInt(this.paidamount);
//    if(this.month < 10){
//     this.da = this.y+"-0"+this.m+"-"+this.d;
//   }else{
//    this.da = this.y+"-"+this.m+"-"+this.d;
//   }
//    if(!this.productname){
//     const toast = await this.toastController.create({
//       message: 'Please Enter Product Name',
//       duration: 2000
//     });
//     toast.present();
//   }else if(!this.customername){
//     const toast = await this.toastController.create({
//       message: 'Please Enter Customer Name',
//       duration: 2000
//     });
//     toast.present();
//   }
//     else if(!this.quantity){
//       const toast = await this.toastController.create({
//         message: 'Please Enter Product Quantity',
//         duration: 2000
//       });
//       toast.present();
//   }else if(!this.unit){
//     const toast = await this.toastController.create({
//       message: 'Please Select Unit',
//       duration: 2000
//     });
//     toast.present();
//   }else if(!this.totalamount){
//     const toast = await this.toastController.create({
//       message: 'Please Enter Total Amount',
//       duration: 2000
//     });
//     toast.present();
//   }
//   else if(!this.date){
//     const toast = await this.toastController.create({
//       message: 'Please Enter Product Date',
//       duration: 2000
//     });
//     toast.present();
//   }
// else{
//   if(this.date == this.da){
//   if(this.pquan>0 && this.ptotal>0 &&this.ppaid>=0)
//   {
//   if(this.ptotal == this.ppaid)
//   {
//  if(!this.productname|| !this.customername  || !this.quantity  || !this.unit || !this.totalamount || !this.paidamount ||!this.date)
//  {   
//    /* alert("please enter the valid details"); */
//    const toast = await this.toastController.create({
//      message: 'Please Enter The Valid Details',
//      duration: 2000
//    });
//    toast.present();
//  }
//   else{
//     this.storage.CreateUser2(this.productname,this.customername,this.quantity,this.unit,this.totalamount,this.paidamount,this.date,this.customerdetails).then( (data) => {
//      console.log("hi");
//       console.log(data);
//       this.r.navigate(['/solditem']);
//     },(error) =>{
     
//      console.log(error);
//   })
//  }

// }
// else{

// if(this.ptotal < this.ppaid || this.ppaid>0){
//  if(!this.productname|| !this.customername  || !this.quantity  || !this.unit || !this.totalamount || !this.paidamount ||!this.date ||!this.customerdetails)
//  {   
//    /* alert("please enter the valid details"); */
//    const toast = await this.toastController.create({
//      message: 'Please Enter The Valid Details',
//      duration: 2000
//    });
//    toast.present();
//  }
//   else{
//     this.storage.CreateUser2(this.productname,this.customername,this.quantity,this.unit,this.totalamount,this.paidamount,this.date,this.customerdetails).then( (data) => {
//      console.log("hi");
//       console.log(data);
//       this.r.navigate(['/solditem']);
//     },(error) =>{
     
//      console.log(error);
//   })
//  }

// }


// else {
//   if(!this.productname|| !this.customername || !this.quantity  || !this.unit || !this.totalamount ||!this.date ||!this.customerdetails)
//  {   
//    /* alert("please enter the valid details"); */
//    const toast = await this.toastController.create({
//      message: 'Please Enter The Details',
//      duration: 2000
//    });
//    toast.present();
//  }
//   else{
//     this.storage.CreateUser2(this.productname,this.customername,this.quantity,this.unit,this.totalamount,this.paidamount,this.date,this.customerdetails).then( (data) => {
//      console.log("hi");
//       console.log(data);
//       this.r.navigate(['/solditem']);
//     },(error) =>{
     
//      console.log(error);
//   })
//  }
// }
//     }  }
// else{
//   const toast = await this.toastController.create({
//     message: 'Please Enter Valid Quantity OR Total Amount OR Paid Amount',
//     duration: 2000
//   });
//   toast.present();
// }
// }
// else{
//   const toast = await this.toastController.create({
//     message: 'Please Select Current Date',
//     duration: 2000
//   });
//   toast.present();
// }
// }
// }
producttype:string;
display(){
  console.log("hiiiiiiiiiiiiiii");
  console.log(this.productname);
  this.display1();
  console.log(this.producttype);
  this.storage.GetSold(this.productname).then((data: any) => {
    this.SoldDetails1=data;
    console.log("hjihxcvbnm");
    console.log(this.SoldDetails1);

  });
}
display1(){
  console.log(this.producttype);
} value="{{item.productname}}"

addsold(){
  console.log(this.productname);
  console.log(this.producttype);
  // this.storage.CreateUser2(this.productname,b,c,d,e,f,g).then( (data) => {
  //        console.log("hi");
  //         console.log(data);
  //         this.r.navigate(['/solditem']);
  //       },(error) =>{
         
  //        console.log(error);
  //     })
}
UnitList:any;
SoldDetails:any;
SoldDetails1:any;
productname:string;

ionViewWillEnter(){
  this.storage.Show_Unit().then((data: any) => {
    console.log(data);
    this.UnitList = data;
  }, (error) => {
    console.log(error);
  })
  this.storage.GetSoldDetails().then((data: any) => {
    this.SoldDetails=data;

  });
 
  
}
  ngOnInit(){
   
  }

}
