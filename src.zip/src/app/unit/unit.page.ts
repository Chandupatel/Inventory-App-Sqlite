import { Component, OnInit } from '@angular/core';
import { InvantoryService } from '../invantory.service';
import { Router } from '@angular/router';
import { ToastController } from '@ionic/angular';

@Component({
  selector: 'app-unit',
  templateUrl: './unit.page.html',
  styleUrls: ['./unit.page.scss'],
})
export class UnitPage implements OnInit {
  UnitList:any;
  constructor(public Storage:InvantoryService,public nvert :Router,private toastController:ToastController) { }
  async Addunit(unit){
    if(!unit){
      const toast = await this.toastController.create({
        message: 'Please Enter Unit',
        duration: 2000
      });
      toast.present();
    }
    else{
    this.Storage.AddUnit(unit).then( (data) => {  
    },(error) =>{ 
     console.log(error);
  })
}
  }
ShowUnit(){
  this.Storage.Show_Unit().then((data: any) => {
    console.log(data);
    this.UnitList = data;
  }, (error) => {
    console.log(error);
  }) 
}
ionViewWillEnter(){
  this.Storage.Show_Unit().then((data: any) => {
    console.log(data);
    this.UnitList = data;
  }, (error) => {
    console.log(error);
  })
   }
   home(){
    this.nvert.navigate(['/home']);
    }
  ngOnInit() {
  }

}
