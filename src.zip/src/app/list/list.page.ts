import { Component, OnInit, OnDestroy } from '@angular/core';
import { InvantoryService } from '../invantory.service';
import { NavController } from '@ionic/angular';
import { Router } from '@angular/router';

@Component({
  selector: 'app-list',
  templateUrl: './list.page.html',
  styleUrls: ['./list.page.scss'],
})
export class ListPage implements OnInit {
  private ListEmployee :any;
  constructor(private storage:InvantoryService, private nvert:Router) {
   
   }
   ionViewWillEnter(){
    this.storage.GetAllEmployee().then((data: any) => {
      console.log(data);
      this.ListEmployee = data;
      }, (error) => {
      console.log(error);
      })
   }

  ngOnInit() {
   }
show_employee(item){

  this.storage.Show_employee(item); 
  this.nvert.navigate(['/view']);
  
}
}
