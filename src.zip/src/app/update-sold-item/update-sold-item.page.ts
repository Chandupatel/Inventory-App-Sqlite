import { Component, OnInit } from '@angular/core';
import { InvantoryService } from '../invantory.service';
import { NavController, ToastController } from '@ionic/angular';
import { Router } from '@angular/router';
@Component({
  selector: 'app-update-sold-item',
  templateUrl: './update-sold-item.page.html',
  styleUrls: ['./update-sold-item.page.scss'],
})
export class UpdateSoldItemPage implements OnInit {
  solddata;
  ids;
  cproductname;
  ccustomername;
  cquantity;
  cunit;
  ctotalamount;
  cpaidamount;
  cdate;
  ccustomerdetails;
  productname:string;
customername:string;
quantity:string;
unit:string;
totalamount:string;
paidamount:string;
date:string;
customerdetails:string; 
  status:boolean;
  status1:boolean;
  status2:boolean;
stat1:boolean;

  constructor(private Storage :InvantoryService,private nvert :NavController,private toastController:ToastController,private r:Router) {
    this.solddata = this.Storage.Returnsolddata();
    this.ids = this.solddata.id;
    this.cproductname = this.solddata.productname;
    this.ccustomername = this.solddata.customername;
    this.cquantity = this.solddata.quantity;
    this.cunit = this.solddata.unit;
    this.ctotalamount = this.solddata.totalamount;
    this.cpaidamount = this.solddata.paidamount;
    this.cdate = this.solddata.date;
    this.ccustomerdetails = this.solddata.customerdetails;
   }
   display1(){
    console.log(this.ctotalamount);
    console.log(this.cpaidamount);
  if(this.ctotalamount==this.cpaidamount){
    this.status=true;
    this.status1=false;
    this.status2=false;
   // this.checked=true;
    this.stat1=false;
  
  } 

      else if(this.ctotalamount>this.cpaidamount && this.cpaidamount!==0 && this.cpaidamount>=0 && this.paidamount!==null){
       this.status1=true;
       this.status=false;
       this.status2=false;
      // this.checked=true;
      this.stat1=true;
      }
    
        else if(this.cpaidamount>this.ctotalamount){
         alert("Invalid entry");
         this.status2=false;
            this.status1=false;
            this.status=false;
           // this.checked=true;
            this.stat1=false;
        }
        else{
          this.status2=true;
          this.status1=false;
          this.status=false;
         // this.checked=true;
          this.stat1=true;
        }
}
pquan;
ptotal;
ppaid;
async addsold(){
  this.pquan= parseInt(this.quantity);
   this.ptotal= parseInt(this.totalamount);
   this.ppaid= parseInt(this.paidamount);
 // console.log(this.cproductname,this.ccustomername,this.cquantity,this.cunit,this.ctotalamount,this.cpaidamount,this.cdate,this.ccustomerdetails,this.ids);
  this.productname=this.cproductname;
  this.customername=this.ccustomername;
  this.quantity=this.cquantity;
  this.unit=this.cunit;
  this.totalamount=this.ctotalamount;
  this.paidamount=this.cpaidamount;
  this.date=this.cdate;
  this.customerdetails=this.ccustomerdetails;
//   if(!this.productname){
//     const toast = await this.toastController.create({
//       message: 'Please Enter Product Name',
//       duration: 2000
//     });
//     toast.present();
//   }else if(!this.customername){
//     const toast = await this.toastController.create({
//       message: 'Please Enter Customer Name',
//       duration: 2000
//     });
//     toast.present();
//   }
//     else if(!this.quantity){
//       const toast = await this.toastController.create({
//         message: 'Please Enter Product Quantity',
//         duration: 2000
//       });
//       toast.present();
//   }else if(!this.unit){
//     const toast = await this.toastController.create({
//       message: 'Please Select Unit',
//       duration: 2000
//     });
//     toast.present();
//   }else if(!this.totalamount){
//     const toast = await this.toastController.create({
//       message: 'Please Enter Total Amount',
//       duration: 2000
//     });
//     toast.present();
//   }
//   else if(!this.date){
//     const toast = await this.toastController.create({
//       message: 'Please Enter Product Date',
//       duration: 2000
//     });
//     toast.present();
//   }
//   else{
//   if(this.pquan>0 && this.ptotal>0 &&this.ppaid>=0)
//   {
//   if(this.ptotal == this.ppaid)
//   {
//  if(!this.productname|| !this.customername  || !this.quantity  || !this.unit || !this.totalamount || !this.paidamount ||!this.date)
//  {   
//    /* alert("please enter the valid details"); */
//    const toast = await this.toastController.create({
//      message: 'Please Enter The Valid Details',
//      duration: 2000
//    });
//    toast.present();
//  }
//   else{
//     this.Storage.update_sold_item(this.productname,this.customername,this.quantity,this.unit,this.totalamount,this.paidamount,this.date,this.customerdetails,this.ids).then( (data) => {
//      console.log("hi");
//       console.log(data);
//       this.r.navigate(['/solditem']);
//     },(error) =>{
     
//      console.log(error);
//   })
//  }

//   }
// else{
//  if(this.ptotal < this.ppaid || this.ppaid>0){
//  if(!this.productname|| !this.customername  || !this.quantity  || !this.unit || !this.totalamount || !this.paidamount ||!this.date ||!this.customerdetails)
//  {   
//    /* alert("please enter the valid details"); */
//    const toast = await this.toastController.create({
//      message: 'Please Enter The Valid Details',
//      duration: 2000
//    });
//    toast.present();
//  }
//   else{
//     this.Storage.update_sold_item(this.productname,this.customername,this.quantity,this.unit,this.totalamount,this.paidamount,this.date,this.customerdetails,this.ids).then( (data) => {
//      console.log("hi");
//       console.log(data);
//       this.r.navigate(['/solditem']);
//     },(error) =>{
     
//      console.log(error);
//   })
//  }

// }
// else{
//  if(!this.productname|| !this.customername || !this.quantity  || !this.unit || !this.totalamount ||!this.date ||!this.customerdetails)
//  {   
//    /* alert("please enter the valid details"); */
//    const toast = await this.toastController.create({
//      message: 'Please Enter The Valid Details',
//      duration: 2000
//    });
//    toast.present();
//  }
//   else{
//     this.Storage.update_sold_item(this.productname,this.customername,this.quantity,this.unit,this.totalamount,this.paidamount,this.date,this.customerdetails,this.ids).then( (data) => {
//      console.log("hi");
//       console.log(data);
//       this.r.navigate(['/solditem']);
//     },(error) =>{
     
//      console.log(error);
//   })
//  }
// }
// }
// }


// else{
//   const toast = await this.toastController.create({
//     message: 'Please Enter Valid Quantity OR Total Amount OR Paid Amount',
//     duration: 2000
//   });
//   toast.present();
// }
//   }

 if(!this.productname){
  const toast = await this.toastController.create({
    message: 'Please Enter Product Name',
    duration: 2000
  });
  toast.present();
}else if(!this.customername){
  const toast = await this.toastController.create({
    message: 'Please Enter Customer Name',
    duration: 2000
  });
  toast.present();
}
  else if(!this.quantity){
    const toast = await this.toastController.create({
      message: 'Please Enter Product Quantity',
      duration: 2000
    });
    toast.present();
}else if(!this.unit){
  const toast = await this.toastController.create({
    message: 'Please Select Unit',
    duration: 2000
  });
  toast.present();
}else if(!this.totalamount){
  const toast = await this.toastController.create({
    message: 'Please Enter Total Amount',
    duration: 2000
  });
  toast.present();
}
else if(!this.date){
  const toast = await this.toastController.create({
    message: 'Please Enter Product Date',
    duration: 2000
  });
  toast.present();
}
else{

if(this.pquan>0 && this.ptotal>0 &&this.ppaid>=0)
{
if(this.ptotal == this.ppaid)
{
if(!this.productname|| !this.customername  || !this.quantity  || !this.unit || !this.totalamount || !this.paidamount ||!this.date)
{   
 /* alert("please enter the valid details"); */
 const toast = await this.toastController.create({
   message: 'Please Enter The Valid Details',
   duration: 2000
 });
 toast.present();
}
else{
  this.Storage.update_sold_item(this.productname,this.customername,this.quantity,this.unit,this.totalamount,this.paidamount,this.date,this.customerdetails,this.ids).then( (data) => {
   console.log("hi");
    console.log(data);
    this.r.navigate(['/solditem']);
  },(error) =>{
   
   console.log(error);
})
}

}
else{

if(this.ptotal < this.ppaid || this.ppaid>0){
if(!this.productname|| !this.customername  || !this.quantity  || !this.unit || !this.totalamount || !this.paidamount ||!this.date ||!this.customerdetails)
{   
 /* alert("please enter the valid details"); */
 const toast = await this.toastController.create({
   message: 'Please Enter The Valid Details',
   duration: 2000
 });
 toast.present();
}
else{
  this.Storage.update_sold_item(this.productname,this.customername,this.quantity,this.unit,this.totalamount,this.paidamount,this.date,this.customerdetails,this.ids).then( (data) => {
   console.log("hi");
    console.log(data);
    this.r.navigate(['/solditem']);
  },(error) =>{
   
   console.log(error);
})
}

}


else {
if(!this.productname|| !this.customername || !this.quantity  || !this.unit || !this.totalamount ||!this.date ||!this.customerdetails)
{   
 /* alert("please enter the valid details"); */
 const toast = await this.toastController.create({
   message: 'Please Enter The Details',
   duration: 2000
 });
 toast.present();
}
else{
  this.Storage.update_sold_item(this.productname,this.customername,this.quantity,this.unit,this.totalamount,this.paidamount,this.date,this.customerdetails,this.ids).then( (data) => {
   console.log("hi");
    console.log(data);
    this.r.navigate(['/solditem']);
  },(error) =>{
   
   console.log(error);
})
}
}
  }  }
else{
const toast = await this.toastController.create({
  message: 'Please Enter Valid Quantity OR Total Amount OR Paid Amount',
  duration: 2000
});
toast.present();
}

}

 }
UnitList:any;
ionViewWillEnter(){
  this.Storage.Show_Unit().then((data: any) => {
    console.log(data);
    this.UnitList = data;
  }, (error) => {
    console.log(error);
  })
   }
  ngOnInit() {
  }

}
