import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { InvantoryService } from '../invantory.service';
import { ToastController } from '@ionic/angular';

@Component({
  selector: 'app-attendance',
  templateUrl: './attendance.page.html',
  styleUrls: ['./attendance.page.scss'],
})
export class AttendancePage implements OnInit {
date="";
constructor( private r:Router,private storage:InvantoryService,private toastcontroller:ToastController) { }
async takeAttendance(date:string){
if(!this.date){
      const toast=await this.toastcontroller.create({
      message:"Please Select Date",
      duration:2000
  });
    toast.present();
}
else{
  //this.storage.AttendanceError(this.date).then( (data) => {  
  this.r.navigate(['atendancelist/', {date:this.date}]); 
this.storage.SetDate(this.date);
}
}

home(){
this.r.navigate(['/home']);
}
ViewAttendance(){
  this.r.navigate(['/attendanceview']);
}
ngOnInit() {
}


}
