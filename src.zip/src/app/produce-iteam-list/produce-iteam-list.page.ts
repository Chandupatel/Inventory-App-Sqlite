import { Component, OnInit } from '@angular/core';
import { InvantoryService } from '../invantory.service';
import { NavController, AlertController } from '@ionic/angular';

@Component({
  selector: 'app-produce-iteam-list',
  templateUrl: './produce-iteam-list.page.html',
  styleUrls: ['./produce-iteam-list.page.scss'],
})
export class ProduceIteamListPage implements OnInit {
  private ListUser : any;
  constructor(private storage:InvantoryService ,private nvert :NavController,public alertController: AlertController) {
      
   }
   ionViewWillEnter(){
    this.storage. Show_All_Production().then((data: any) => {
      console.log(data);
      this.ListUser = data;
    }, (error) => {
      console.log(error);
    }) 
   }
  ngOnInit() {
    
  }

  Edit_Produse(item){
    this.storage.EditProduction(item);
    /* this.nvert.navigateRoot("/edit-produce-iteam"); */
  }
// flag;
// Delete_Produse(item,j){
//   this.flag=!this.flag;
//   this.ListUser.splice(j,1);
//   var id =item.id;
//   this.storage.Delete_Producation(item,id).then( (data) => { 
//     this.flag=!this.flag;
//     console.log("Done"+data);
//   },(error) =>{
//    console.log("Not Done"+error);
//     })
//   }

flag;
async Delete_Produse(item,j){
  var id =item.id;
  const alert = await this.alertController.create({
    header: 'Confirm!',
    message: 'Are You Sure You Want To Delete Data ?',
    buttons: [
      {
        text: 'Cancel',
        role: 'cancel',
        cssClass: 'secondary',
        handler: (blah) => {
          console.log('Confirm Cancel: blah');
        }
      }, {
        text: 'Okay',
        handler: () => {
          this.flag=!this.flag;
          this.ListUser.splice(j,1);
          this.storage.Delete_Producation(item,id).then( (data) => { 
          this.flag=!this.flag;
            console.log("Done"+data);
          },(error) =>{
           console.log("Not Done"+error);
            })
        }
      }
    ]
  });
  await alert.present();
 }


}
