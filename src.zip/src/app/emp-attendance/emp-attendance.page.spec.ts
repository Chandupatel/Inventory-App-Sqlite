import { CUSTOM_ELEMENTS_SCHEMA } from '@angular/core';
import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { EmpAttendancePage } from './emp-attendance.page';

describe('EmpAttendancePage', () => {
  let component: EmpAttendancePage;
  let fixture: ComponentFixture<EmpAttendancePage>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ EmpAttendancePage ],
      schemas: [CUSTOM_ELEMENTS_SCHEMA],
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(EmpAttendancePage);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
