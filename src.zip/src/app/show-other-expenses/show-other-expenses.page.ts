import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-show-other-expenses',
  templateUrl: './show-other-expenses.page.html',
  styleUrls: ['./show-other-expenses.page.scss'],
})
export class ShowOtherExpensesPage implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
