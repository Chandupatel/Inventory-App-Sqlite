import { Component, OnInit } from '@angular/core';
import { InvantoryService } from '../invantory.service';
import { NavController, AlertController } from '@ionic/angular';
@Component({
  selector: 'app-solditem',
  templateUrl: './solditem.page.html',
  styleUrls: ['./solditem.page.scss'],
})
export class SolditemPage implements OnInit {

  constructor(private storage:InvantoryService,private navcrt:NavController,private alertcontroller:AlertController) { }
  private ListUser1 : any;
  ionViewWillEnter(){
    this.storage.GetAllUsers2().then((data: any) => {
      console.log(data);
      this.ListUser1 = data;
      console.log(this.ListUser1);
     // alert( " Show Data "+ this.ListUser1.productname+"\n")
    }, (error) => {
      console.log(error);
    })
  }
  ngOnInit() {}
    
  update1(item){
   // alert(item.productname);
    this.storage.solditem(item);
    console.log("ashra");
   // this.navcrt.navigateRoot("/update-sold-item");

  }
//   flag;
//  delete1(item,j){
//   //alert( "delete" + item.productname);
//   this.flag=!this.flag;
//   this.ListUser1.splice(j,1);
// var id =item.id;
// console.log(id);
//   this.storage. Deletesolditem(id).then( (data) => { 
//     console.log("Done"+data);
//   }
//   ,(error) =>{
//    console.log("Not Done"+error);
// })
//  }

flag;
async delete1(item,j){
  var id =item.id;
  const alert = await this.alertcontroller.create({
    header: 'Confirm!',
    message: 'Are You Sure You Want To Delete Data ?',
    buttons: [
      {
        text: 'Cancel',
        role: 'cancel',
        cssClass: 'secondary',
        handler: (blah) => {
          console.log('Confirm Cancel: blah');
        }
      }, {
        text: 'Okay',
        handler: () => {
          this.flag=!this.flag;
          this.ListUser1.splice(j,1);
          this.storage. Deletesolditem(id).then( (data) =>  { 
          this.flag=!this.flag;
            console.log("Done"+data);
          },(error) =>{
           console.log("Not Done"+error);
            })
        }
      }
    ]
  });
  await alert.present();
 }


}
