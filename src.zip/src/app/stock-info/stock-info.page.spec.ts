import { CUSTOM_ELEMENTS_SCHEMA } from '@angular/core';
import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { StockInfoPage } from './stock-info.page';

describe('StockInfoPage', () => {
  let component: StockInfoPage;
  let fixture: ComponentFixture<StockInfoPage>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ StockInfoPage ],
      schemas: [CUSTOM_ELEMENTS_SCHEMA],
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(StockInfoPage);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
