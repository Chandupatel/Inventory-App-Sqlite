import { Component, OnInit } from '@angular/core';
import { InvantoryService } from '../invantory.service';
import { ActivatedRoute } from '@angular/router';

@Component({
  selector: 'app-stock-details',
  templateUrl: './stock-details.page.html',
  styleUrls: ['./stock-details.page.scss'],
})
export class StockDetailsPage implements OnInit {

  From="";
  producttype="";
  list:any;
  StockDetails:any;
  totallist:any;
  constructor(private storage:InvantoryService,private s:ActivatedRoute) {
    this.From=this.s.snapshot.paramMap.get('From');
    this.producttype=this.s.snapshot.paramMap.get('producttype');
   }

   ngOnInit(){
    this.storage.GetStockDetails(this.From,this.producttype).then((data: any) => {
    this.StockDetails=data;
    //console.log(data);
    
    /* this.storage.GetStockpurchase(this.From).then((res: any) => {
      this.StockPurchase=res; */
  });
  } 
}