import { NgModule } from '@angular/core';
import { PreloadAllModules, RouterModule, Routes } from '@angular/router';

const routes: Routes = [
  { path: '', redirectTo: 'home', pathMatch: 'full' },
  { path: 'home', loadChildren: './home/home.module#HomePageModule' },
  { path: 'produce-iteam-list', loadChildren: './produce-iteam-list/produce-iteam-list.module#ProduceIteamListPageModule' },
  { path: 'produce-iteam-summary', loadChildren: './produce-iteam-summary/produce-iteam-summary.module#ProduceIteamSummaryPageModule' },
  {path:'stock-info', loadChildren:'./stock-info/stock-info.module#StockInfoPageModule'},
  {path:'stock-details', loadChildren:'./stock-details/stock-details.module#StockDetailsPageModule'},
  { path: 'purchaseitem', loadChildren: './purchaseitem/purchaseitem.module#PurchaseitemPageModule' },
  { path: 'solditem', loadChildren: './solditem/solditem.module#SolditemPageModule' },
  { path: 'purchase-item-summary', loadChildren: './purchase-item-summary/purchase-item-summary.module#PurchaseItemSummaryPageModule' },
  { path: 'sold-item-summary', loadChildren: './sold-item-summary/sold-item-summary.module#SoldItemSummaryPageModule' },
  { path: 'add-sold-item', loadChildren: './add-sold-item/add-sold-item.module#AddSoldItemPageModule' },
  { path: 'add-purchase-item', loadChildren: './add-purchase-item/add-purchase-item.module#AddPurchaseItemPageModule' },
  { path: 'list', loadChildren: './list/list.module#ListPageModule' },
  { path: 'add', loadChildren: './add/add.module#AddPageModule' },
  { path: 'view', loadChildren: './view/view.module#ViewPageModule' },
  { path: 'add-new-production', loadChildren: './add-new-production/add-new-production.module#AddNewProductionPageModule' },
  { path: 'edit-produce-iteam', loadChildren: './edit-produce-iteam/edit-produce-iteam.module#EditProduceIteamPageModule' },
  { path: 'profit-loss', loadChildren: './profit-loss/profit-loss.module#ProfitLossPageModule' },
  { path: 'profit-loss-status', loadChildren: './profit-loss-status/profit-loss-status.module#ProfitLossStatusPageModule' }, 
  { path: 'attendance', loadChildren: './attendance/attendance.module#AttendancePageModule' },
  { path: 'atendancelist', loadChildren: './atendancelist/atendancelist.module#AtendancelistPageModule' },
  { path: 'emp-attendance', loadChildren: './emp-attendance/emp-attendance.module#EmpAttendancePageModule' },
  { path: 'add-other-expenses', loadChildren: './add-other-expenses/add-other-expenses.module#AddOtherExpensesPageModule' },
  { path: 'other-expenses-list', loadChildren: './other-expenses-list/other-expenses-list.module#OtherExpensesListPageModule' },
  { path: 'update-purchase-item', loadChildren: './update-purchase-item/update-purchase-item.module#UpdatePurchaseItemPageModule' },
  { path: 'update-sold-item', loadChildren: './update-sold-item/update-sold-item.module#UpdateSoldItemPageModule' },
  { path: 'register-page', loadChildren: './register-page/register-page.module#RegisterPagePageModule' },
  { path: 'login-page', loadChildren: './login-page/login-page.module#LoginPagePageModule' },
  { path: 'mainpage', loadChildren: './mainpage/mainpage.module#MainpagePageModule' },
  { path: 'employeeattendance', loadChildren: './employeeattendance/employeeattendance.module#EmployeeattendancePageModule' },
  { path: 'show-other-expenses', loadChildren: './show-other-expenses/show-other-expenses.module#ShowOtherExpensesPageModule' },
  { path: 'unit', loadChildren: './unit/unit.module#UnitPageModule' },
 
];


@NgModule({
  imports: [
    RouterModule.forRoot(routes, { preloadingStrategy: PreloadAllModules })
  ],
  exports: [RouterModule]
})
export class AppRoutingModule { }