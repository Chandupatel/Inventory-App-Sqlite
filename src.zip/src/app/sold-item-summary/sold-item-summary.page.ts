import { Component, OnInit } from '@angular/core';
import { InvantoryService } from '../invantory.service';
import { NavController, ToastController, AlertController } from '@ionic/angular';

@Component({
  selector: 'app-sold-item-summary',
  templateUrl: './sold-item-summary.page.html',
  styleUrls: ['./sold-item-summary.page.scss'],
})
export class SoldItemSummaryPage implements OnInit {

  constructor(private Storage :InvantoryService,private navcrt:NavController,private toastController:ToastController,private alertcontroller:AlertController) { }
  private ListUser : any;
  totalamount1=0;

  async SelectSummary(from,to){
    if(!from|| !to ){
      const toast =await this.toastController.create({
        message:"Please Enter The Valid Details",
        duration: 2000
      });
      toast.present();
    }
    else if(from>to){
      console.log("hyeeeeeeeee");
      const toast =await this.toastController.create({
        message:"Please Enter Correct Format",
        duration: 2000
      });
      toast.present();
      
    }
    else{
    this.Storage.Sold_Summary(from,to).then((data: any) => {
      console.log("Done"+data);
      this.ListUser = data;
      for(let i=0;i<=this.ListUser.length;i++){
        console.log("hello");
        var total= parseInt(this.ListUser[i].totalamount);
        console.log("hjjjj");
        this.totalamount1=this.totalamount1+total;
        console.log(this.totalamount1);
      }
    }, (error) => {
      console.log("Error"+error);
    })
  }
}
  
  Edit_Sold_Summary(item){
    //alert(item.productname);
    this.Storage.solditem(item);
    //this.navcrt.navigateRoot("/update-sold-item");

  }
//   flag;
// Delete_Sold_Summary(item,j){
//   //alert( "delete" + item.productname);
//   this.flag=!this.flag;
//   this.ListUser.splice(j,1);
//   var id =item.id;
//   this.Storage. Deletesolditem(id).then( (data) => { 
//     console.log("Done"+data);
//     console.log("Done"+data);
//   },(error) =>{
//    console.log("Not Done"+error);
//     })
//   }
flag;
async Delete_Sold_Summary(item,j){
  var id =item.id;
  const alert = await this.alertcontroller.create({
    header: 'Confirm!',
    message: 'Are You Sure You Want To Delete Data ?',
    buttons: [
      {
        text: 'Cancel',
        role: 'cancel',
        cssClass: 'secondary',
        handler: (blah) => {
          console.log('Confirm Cancel: blah');
        }
      }, {
        text: 'Okay',
        handler: () => {
          this.flag=!this.flag;
          this.ListUser.splice(j,1);
          this.Storage. Deletesolditem(id).then( (data) =>  { 
          this.flag=!this.flag;
            console.log("Done"+data);
          },(error) =>{
           console.log("Not Done"+error);
            })
        }
      }
    ]
  });
  await alert.present();
 }


  ngOnInit() {
  }

}
