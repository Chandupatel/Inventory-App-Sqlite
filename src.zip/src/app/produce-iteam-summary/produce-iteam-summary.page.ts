import { Component, OnInit } from '@angular/core';
import { InvantoryService } from '../invantory.service';
import { NavController, AlertController } from '@ionic/angular';

@Component({
  selector: 'app-produce-iteam-summary',
  templateUrl: './produce-iteam-summary.page.html',
  styleUrls: ['./produce-iteam-summary.page.scss'],
})
export class ProduceIteamSummaryPage implements OnInit {
  
  constructor( private Storage : InvantoryService,private nvert :NavController,public alertController: AlertController) { 

  }
  public ListUser : any;
  total=0;
  SelecSumm(form,to){
    this.Storage.Select_Summary(form,to).then((data: any) => {
      console.log("Done"+data);
      this.ListUser = data;
      for(let i=0;i<this.ListUser.length;i++){
        var num = parseInt(this.ListUser[i].amount);
        this.total= this.total+ num;
      }
    }, (error) => {
      console.log("Error"+error);
    })
   
  }

  Edit_Produse(item){
    this.Storage.EditProduction(item);
  }
  
  // flag;
  // Delete_Produse(item,j){
  // this.flag=!this.flag;
  // this.ListUser.splice(j,1);
  // var id =item.id;
  // var amt =parseInt(item.amount);
  // this.total= this.total -amt;
  // this.Storage. Delete_Producation(item,id).then( (data) => { 
  //   this.flag=!this.flag;
  //   console.log("Done"+data);
  // },(error) =>{ 
  //  console.log("Not Done"+error);
  //   })
  // }
  
  flag;
  async Delete_Produse(item,j){
    var id =item.id;
    const alert = await this.alertController.create({
      header: 'Confirm!',
      message: 'Are You Sure You Want To Delete Data ?',
      buttons: [
        {
          text: 'Cancel',
          role: 'cancel',
          cssClass: 'secondary',
          handler: (blah) => {
            console.log('Confirm Cancel: blah');
          }
        }, {
          text: 'Okay',
          handler: () => {
            this.flag=!this.flag;
            this.ListUser.splice(j,1);
            this.Storage.Delete_Producation(item,id).then( (data) => { 
            this.flag=!this.flag;
              console.log("Done"+data);
            },(error) =>{
             console.log("Not Done"+error);
              })
          }
        }
      ]
    });
    await alert.present();
   }
  
  
  
  
  
  
  ngOnInit() {


  }


}
