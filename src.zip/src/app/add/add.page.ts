import { Component, OnInit } from '@angular/core';
import { InvantoryService } from '../invantory.service';
import { Router } from '@angular/router';
import { ToastController, NavController } from '@ionic/angular';

@Component({
  selector: 'app-add',
  templateUrl: './add.page.html',
  styleUrls: ['./add.page.scss'],
})
export class AddPage implements OnInit {

  constructor(private storage:InvantoryService,public toastController: ToastController,private nvert: Router) { }
  re=/\w+@\w+\.\w+/;
  done;
  amount; 
  async Add_employee(name,contact,email,salary,mode,address){
    this.amount=parseInt(salary);

    if(!name){
      const toast = await this.toastController.create({
        message: 'Please Enter Name.',
        duration: 2000
      });
      toast.present();
    }
    else if(!contact){
      const toast = await this.toastController.create({
        message: 'Please Enter contact.',
        duration: 2000
      });
      toast.present();
    }
    else if(!email){
      const toast = await this.toastController.create({
        message: 'Please Enter Email.',
        duration: 2000
      });
      toast.present();
    }
    else if(!this.amount){
      const toast = await this.toastController.create({
        message: 'Please Enter salary.',
        duration: 2000
      });
      toast.present();
    }
    else if(!mode){
      const toast = await this.toastController.create({
        message: 'Please Enter mode.',
        duration: 2000
      });
      toast.present();
    }
    else if(!address){
      const toast = await this.toastController.create({
        message: 'Please Enter address.',
        duration: 2000
      });
      toast.present();
    }
    else{
      if(contact.length==10 && contact.indexOf('0')!==0){
        this.done =  this.re.test(email);
        if(!this.done){
          const toast = await this.toastController.create({
            message: 'Please Enter The Valid Email',
            duration: 2000
          });
          toast.present();
         }
         else{

          if(this.amount>0){
            this.storage.Addemployee(name,contact,email,this.amount,mode,address).then((data)=>{
              console.log(data);
              this.nvert.navigate(['/list']);
            },(error)=>{
              console.log(error);
            })
          }else{

            const toast = await this.toastController.create({
              message: 'Please Enter The Valid Salary',
              duration: 2000
            });
            toast.present();
          
         }}
    }
    else{
      const toast = await this.toastController.create({
        message: 'Please Enter The Valid Mobile No',
        duration: 2000
      });
      toast.present();
    }
    }
  }
  ngOnInit() {
  }

}
