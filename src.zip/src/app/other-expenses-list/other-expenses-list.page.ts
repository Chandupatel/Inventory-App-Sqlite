import { Component, OnInit } from '@angular/core';
import { InvantoryService } from '../invantory.service';
import { ToastController } from '@ionic/angular';

@Component({
  selector: 'app-other-expenses-list',
  templateUrl: './other-expenses-list.page.html',
  styleUrls: ['./other-expenses-list.page.scss'],
})
export class OtherExpensesListPage implements OnInit {
  private OtherExpList : any;

  
   constructor(private Storage:InvantoryService,public toastController: ToastController) { }
   
   Show_other_Exp(date){
    this.Storage.Select_Other_Exp(date).then((data: any) => {
      console.log(data);
      this.OtherExpList = data;
    }, (error) => {
      console.log(error);
  })
  }
  

  ionViewWillEnter(){
    this.Storage.Show_All_Expenses().then((data: any) => {
      console.log(data);
      this.OtherExpList = data;
    }, (error) => {
      console.log(error);
    }) 
   }

  ngOnInit() {
  }

}
