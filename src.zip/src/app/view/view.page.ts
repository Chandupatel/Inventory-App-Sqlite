import { Component, OnInit } from '@angular/core';
import { InvantoryService } from '../invantory.service';
import { NavController, AlertController } from '@ionic/angular';
import {ToastController} from '@ionic/angular';
import { Router } from '@angular/router';

@Component({
  selector: 'app-view',
  templateUrl: './view.page.html',
  styleUrls: ['./view.page.scss'],
})
export class ViewPage implements OnInit {
empalldata;
ids;
name;
contact;
email;
salary;
mode;
address;

 
  constructor( private storage:InvantoryService,private router:Router,public toastcontroller:ToastController,private alertcontroller:AlertController) {
   }
   ionViewWillEnter(){
    this.empalldata=this.storage.returnempdata();
    this.ids=this.empalldata.id;
    this.name=this.empalldata.employeename;
    this.contact=this.empalldata.contact;
    this.email=this.empalldata.email;
    this.salary=this.empalldata.salary;
    this.mode=this.empalldata.mode;
    this.address=this.empalldata.address; 
   }
  async delete(){
    var id=this.ids;
 
    const alert = await this.alertcontroller.create({
     header: 'Confirm!',
     message: '<strong>Are You Sure You Want To Delete Data</strong>?',
     buttons: [
       {
         text: 'Cancel',
         role: 'cancel',
         cssClass: 'secondary',
         handler: (blah) => {
           console.log('Confirm Cancel: blah');
         }
       }, {
         text: 'Okay',
         handler: async () => {
           this.storage.Delete_Employee(id).then((data)=>{
             console.log("done"+data);
           },(error)=>{
             console.log("not done"+error);
           })
           const toast = await this.toastcontroller.create({
            message: 'Your data successfully delete.',
            duration: 2000
          });
          toast.present();
          this.router.navigate(['/list']);
         }
       }
     ]
   });
 
   await alert.present();
   }
  re=/\w+@\w+\.\w+/;
  done;
  amount;
  async edit(name,contact,email,salary,mode,address){
    this.amount=parseInt(salary);
if(!name){
  const toast = await this.toastcontroller.create({
    message: 'Please Enter Name.',
    duration: 2000
  });
  toast.present();
}
else if(!contact){
  const toast = await this.toastcontroller.create({
    message: 'Please Enter contact.',
    duration: 2000
  });
  toast.present();
}
else if(!email){
  const toast = await this.toastcontroller.create({
    message: 'Please Enter Email.',
    duration: 2000
  });
  toast.present();
}
else if(!this.amount){
  const toast = await this.toastcontroller.create({
    message: 'Please Enter salary.',
    duration: 2000
  });
  toast.present();
}
else if(!mode){
  const toast = await this.toastcontroller.create({
    message: 'Please Enter mode.',
    duration: 2000
  });
  toast.present();
}
else if(!address){
  const toast = await this.toastcontroller.create({
    message: 'Please Enter address.',
    duration: 2000
  });
  toast.present();
}
else{
  if(contact.length==10 && contact.indexOf('0')!==0){
    this.done =  this.re.test(email);
    if(!this.done){
      const toast = await this.toastcontroller.create({
        message: 'Please Enter The Valid Email',
        duration: 2000
      });
      toast.present();
     }
     else{

      if(this.amount>0){
        this.storage.Update_employee(this.ids,name,contact,email,this.amount,mode,address).then((data)=>{
          console.log(data);
          this.router.navigate(['/list']);
        },(error)=>{
          console.log(error);
        })
      }else{

        const toast = await this.toastcontroller.create({
          message: 'Please Enter The Valid Salary',
          duration: 2000
        });
        toast.present();
      
     }}
}
else{
  const toast = await this.toastcontroller.create({
    message: 'Please Enter The Valid Mobile No',
    duration: 2000
  });
  toast.present();
}
}
}

  ngOnInit() {
  }
}
  
 


