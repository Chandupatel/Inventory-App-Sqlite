import { Component, OnInit } from '@angular/core';
import { InvantoryService } from '../invantory.service';
import { ActivatedRoute, Router } from '@angular/router';
import { ToastController } from '@ionic/angular';

@Component({
  selector: 'app-profit-loss-status',
  templateUrl: './profit-loss-status.page.html',
  styleUrls: ['./profit-loss-status.page.scss'],
})
export class ProfitLossStatusPage implements OnInit {

 ProductionList:any;
 PurchasedList:any;
 SoldList:any;
 ExpenseList:any;
 From="";
 To="";
 purchaseamount="";
 producedamount="";
 expenseamount="";
 Sum;
 profit;
 loss;
status:boolean =false;

constructor(private storage:InvantoryService,private s:ActivatedRoute ,private router:Router,private toastController:ToastController)
 { 
    this.From=this.s.snapshot.paramMap.get('From');
    this.To=this.s.snapshot.paramMap.get('To');
  }//Constructor Close
  ngOnInit() 
  {
    this.storage.GetProductionFinal(this.From,this.To).then((data: any) => 
    {
     this.ProductionList=data;

     this.display();
     console.log( this.ProductionList);
     }, 
     (error) => 
     {
       console.log("err");
       console.log(error);
     });


  //    //purchased query
    this.storage.GetPurchasedFinal(this.From,this.To).then((data: any) => 
    {
       this.PurchasedList=data;
       console.log(this.PurchasedList);
       this.display();
   }, 
   (error) =>
    {
     console.log(error);
   });
   

    //sold query
    this.storage.GetSoldFinal(this.From,this.To).then((data: any) => 
    {
      this.SoldList=data;
      this.display();
      console.log(this.SoldList);
   }, 
   (error) => 
   {
     console.log("err");
     console.log(error);
   });

 //expense query
   this.storage.GetExpenseFinal(this.From,this.To).then((data: any) => 
   {
     console.log("data");
     console.log(data);
    this.ExpenseList=data;
  
    this.display();
   },
   (error) => 
   {
  console.log(error);
   });

  }
  async display()
{
    this.purchaseamount=this.PurchasedList[0].totalpurchaseamount;
    this.producedamount=this.ProductionList[0].totalproductionamount;
    this.expenseamount=this.ExpenseList[0].totalexpenseamount;
    var soldamount=this.SoldList[0].totalsoldamount;
    this.Sum=(this.producedamount+this.purchaseamount+this.expenseamount);
   this.profit= soldamount-this.Sum;
    this.loss=this.Sum-soldamount;

  if(this.profit>0)
  {
    this.status=true;
    console.log("hyeeeeeeeee");
    const toast =await this.toastController.create({
      message:"You have Profit"+" "+"Rs."+" "+this.profit,
      duration: 2000
    });
    toast.present();
  } 
  else if(this.profit<0)
  {
    this.status=false;
    console.log("hyeeeeeeeee");
    const toast =await this.toastController.create({
      message:"You have Loss"+" "+"Rs."+" "+this.loss,
      duration: 2000
    });
    toast.present();
  }
else{
  console.log("hyeeeeeeeee");
  const toast =await this.toastController.create({
    message:"No Profit or No Loss or Data Not Found",
    duration: 2000
  });
  toast.present();
  // this.router.navigate(['/profit-loss']);
}
}
 

}
