import { CUSTOM_ELEMENTS_SCHEMA } from '@angular/core';
import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { ProfitLossStatusPage } from './profit-loss-status.page';

describe('ProfitLossStatusPage', () => {
  let component: ProfitLossStatusPage;
  let fixture: ComponentFixture<ProfitLossStatusPage>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ ProfitLossStatusPage ],
      schemas: [CUSTOM_ELEMENTS_SCHEMA],
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(ProfitLossStatusPage);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
