import { Component, OnInit } from '@angular/core';
import { InvantoryService } from '../invantory.service';
import { NavController, ToastController, AlertController } from '@ionic/angular';

@Component({
  selector: 'app-purchase-item-summary',
  templateUrl: './purchase-item-summary.page.html',
  styleUrls: ['./purchase-item-summary.page.scss'],
})
export class PurchaseItemSummaryPage implements OnInit {
  constructor(private Storage:InvantoryService,private navcrt:NavController,private toastController:ToastController,private alertController:AlertController) { }
  private ListUser : any;
  private totalamount=0;
 async Purchase_summary(From,To){
    if(!From|| !To ){
      const toast =await this.toastController.create({
        message:"Please Enter The Valid Details",
        duration: 2000
      });
      toast.present();
    }
    else if(From>To){
      console.log("hyeeeeeeeee");
      const toast =await this.toastController.create({
        message:"Please Enter Correct Format",
        duration: 2000
      });
      toast.present();
      
    }
    else{
    this.Storage.Purchase_Summary(From,To).then((data: any) => {
      console.log("Done"+data);
      this.ListUser = data;
      for(let i=0;i<=this.ListUser.length;i++){
        var total= parseInt(this.ListUser[i].totalamount);
        this.totalamount=this.totalamount+total;
        console.log(this.totalamount);
      }
    }, (error) => {
      console.log("Error"+error);
    })
  }
  }
  Edit_Purchase(item){
   // alert(item.productname);
    this.Storage.updateitem(item);
    //this.navcrt.navigateRoot("/update-purchase-item");
  }
  // flag;
  // Delete_Purchase(item,j){
  //  // alert( "delete" + item.productname);
  // this.flag=!this.flag;
  // this.ListUser.splice(j,1);
  // var id =item.id;
  // this.Storage. Deletepurchaseitem(item,id).then( (data) => { 
  //   console.log("Done"+data);
  //   console.log("Done"+data);
  //   this.flag=!this.flag;
  //   console.log("Done"+data);
  // },(error) =>{
   
  //  console.log("Not Done"+error);
  //   })
  // }
  flag;
async Delete_Purchase(item,j){
  var id =item.id;
  const alert = await this.alertController.create({
    header: 'Confirm!',
    message: 'Are You Sure You Want To Delete Data ?',
    buttons: [
      {
        text: 'Cancel',
        role: 'cancel',
        cssClass: 'secondary',
        handler: (blah) => {
          console.log('Confirm Cancel: blah');
        }
      }, {
        text: 'Okay',
        handler: () => {
          this.flag=!this.flag;
          this.ListUser.splice(j,1);
          this.Storage. Deletepurchaseitem(item,id).then( (data) =>  { 
          this.flag=!this.flag;
            console.log("Done"+data);
          },(error) =>{
           console.log("Not Done"+error);
            })
        }
      }
    ]
  });
  await alert.present();
 }






  ngOnInit() {
  }

}
