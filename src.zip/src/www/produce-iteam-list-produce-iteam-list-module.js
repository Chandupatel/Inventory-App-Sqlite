(window["webpackJsonp"] = window["webpackJsonp"] || []).push([["produce-iteam-list-produce-iteam-list-module"],{

/***/ "./src/app/produce-iteam-list/produce-iteam-list.module.ts":
/*!*****************************************************************!*\
  !*** ./src/app/produce-iteam-list/produce-iteam-list.module.ts ***!
  \*****************************************************************/
/*! exports provided: ProduceIteamListPageModule */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "ProduceIteamListPageModule", function() { return ProduceIteamListPageModule; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm5/core.js");
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/common */ "./node_modules/@angular/common/fesm5/common.js");
/* harmony import */ var _angular_forms__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/forms */ "./node_modules/@angular/forms/fesm5/forms.js");
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @angular/router */ "./node_modules/@angular/router/fesm5/router.js");
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @ionic/angular */ "./node_modules/@ionic/angular/dist/fesm5.js");
/* harmony import */ var _produce_iteam_list_page__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! ./produce-iteam-list.page */ "./src/app/produce-iteam-list/produce-iteam-list.page.ts");







var routes = [
    {
        path: '',
        component: _produce_iteam_list_page__WEBPACK_IMPORTED_MODULE_6__["ProduceIteamListPage"]
    }
];
var ProduceIteamListPageModule = /** @class */ (function () {
    function ProduceIteamListPageModule() {
    }
    ProduceIteamListPageModule = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["NgModule"])({
            imports: [
                _angular_common__WEBPACK_IMPORTED_MODULE_2__["CommonModule"],
                _angular_forms__WEBPACK_IMPORTED_MODULE_3__["FormsModule"],
                _ionic_angular__WEBPACK_IMPORTED_MODULE_5__["IonicModule"],
                _angular_router__WEBPACK_IMPORTED_MODULE_4__["RouterModule"].forChild(routes)
            ],
            declarations: [_produce_iteam_list_page__WEBPACK_IMPORTED_MODULE_6__["ProduceIteamListPage"]]
        })
    ], ProduceIteamListPageModule);
    return ProduceIteamListPageModule;
}());



/***/ }),

/***/ "./src/app/produce-iteam-list/produce-iteam-list.page.html":
/*!*****************************************************************!*\
  !*** ./src/app/produce-iteam-list/produce-iteam-list.page.html ***!
  \*****************************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = "<ion-header>\r\n    <ion-title>produce_Iteam_List</ion-title>\r\n</ion-header>\r\n\r\n<ion-content>\r\n    <ion-row>\r\n        <ion-col size=\"6\">\r\n        </ion-col>\r\n      </ion-row>\r\n\r\n    <ion-row>\r\n        <ion-col size=\"6\" id=\"prd\">\r\n           <a routerLink=\"/produce-iteam-summary\"><ion-button shape=\"round\" color=\"light\" id=\"button11\" ><ion-icon name=\"apps\"></ion-icon></ion-button></a><br>\r\n            <label id=\"butlable\">Summary</label>\r\n        </ion-col>\r\n        <ion-col size=\"6\">\r\n           <a  routerLink=\"/add-new-production\">  <ion-button  shape=\"round\" color=\"light\" id=\"button11\" ><ion-icon name=\"add-circle-outline\"></ion-icon></ion-button></a>\r\n             <br> <label>Add New Production</label>\r\n          </ion-col>\r\n      </ion-row>\r\n      <hr>\r\n      <ion-card id=\"proitmcard\"  *ngFor=\"let item of ListUser\">\r\n          <ion-card-content>\r\n          <ion-row>\r\n              <ion-col size=\"8\">\r\n                  {{item.productname}}\r\n              </ion-col>\r\n              <ion-col size=\"2\">\r\n                  <ion-icon name=\"create\"></ion-icon>\r\n                </ion-col>\r\n                <ion-col size=\"2\">\r\n                    <ion-icon name=\"trash\"></ion-icon>\r\n                  </ion-col>\r\n            </ion-row>\r\n            <ion-row>\r\n                <ion-col size=\"8\">\r\n                    {{item.quantity}}\r\n                </ion-col>\r\n                <ion-col size=\"4\">\r\n                    {{item.amount}}\r\n                  </ion-col>\r\n              </ion-row>\r\n            </ion-card-content>\r\n\r\n\r\n\r\n\r\n\r\n\r\n        <!-- <ion-card-header>\r\n          <ion-card-subtitle></ion-card-subtitle>\r\n          <ion-card-title></ion-card-title>\r\n        </ion-card-header>\r\n       \r\n            {{item.productname}} <br>\r\n            {{item. producttype}}            \r\n          </ion-card-content> -->\r\n    </ion-card>\r\n</ion-content>\r\n"

/***/ }),

/***/ "./src/app/produce-iteam-list/produce-iteam-list.page.scss":
/*!*****************************************************************!*\
  !*** ./src/app/produce-iteam-list/produce-iteam-list.page.scss ***!
  \*****************************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = "#prd {\n  align-content: center; }\n\n#button11 {\n  width: 70px;\n  height: 72px;\n  border-radius: 30px;\n  font-size: 50px;\n  margin-left: 50px; }\n\n#butlable {\n  margin-left: 50px; }\n\nhr {\n  height: 2px !important;\n  width: 500px !important;\n  background: black !important;\n  display: block !important;\n  font-size: 2em !important;\n  opacity: 1 !important;\n  visibility: visible !important; }\n\n#proitmcard {\n  border: 2px solid darkcyan;\n  border-radius: 30px; }\n\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbInNyYy9hcHAvcHJvZHVjZS1pdGVhbS1saXN0L0M6XFxVc2Vyc1xcQXZpbmFzaCBrdW5kYWxcXERlc2t0b3BcXEludmVudGFyeSBpb25pYyBhcHBcXEludmVudG9yeS9zcmNcXGFwcFxccHJvZHVjZS1pdGVhbS1saXN0XFxwcm9kdWNlLWl0ZWFtLWxpc3QucGFnZS5zY3NzIl0sIm5hbWVzIjpbXSwibWFwcGluZ3MiOiJBQUFBO0VBQ0kscUJBQXFCLEVBQUE7O0FBRXpCO0VBQ0ksV0FBVztFQUNYLFlBQVk7RUFDWixtQkFBbUI7RUFDbkIsZUFBZTtFQUNmLGlCQUFpQixFQUFBOztBQUVyQjtFQUNJLGlCQUFpQixFQUFBOztBQUdyQjtFQUVJLHNCQUFzQjtFQUN0Qix1QkFBdUI7RUFDdkIsNEJBQW1DO0VBQ25DLHlCQUF5QjtFQUN6Qix5QkFBeUI7RUFDekIscUJBQXFCO0VBQ3JCLDhCQUE4QixFQUFBOztBQUdsQztFQUNJLDBCQUEwQjtFQUMxQixtQkFBbUIsRUFBQSIsImZpbGUiOiJzcmMvYXBwL3Byb2R1Y2UtaXRlYW0tbGlzdC9wcm9kdWNlLWl0ZWFtLWxpc3QucGFnZS5zY3NzIiwic291cmNlc0NvbnRlbnQiOlsiI3ByZHtcclxuICAgIGFsaWduLWNvbnRlbnQ6IGNlbnRlcjtcclxufVxyXG4jYnV0dG9uMTF7XHJcbiAgICB3aWR0aDogNzBweDtcclxuICAgIGhlaWdodDogNzJweDtcclxuICAgIGJvcmRlci1yYWRpdXM6IDMwcHg7XHJcbiAgICBmb250LXNpemU6IDUwcHg7XHJcbiAgICBtYXJnaW4tbGVmdDogNTBweDtcclxufVxyXG4jYnV0bGFibGV7XHJcbiAgICBtYXJnaW4tbGVmdDogNTBweDtcclxuXHJcbn1cclxuaHJ7XHJcbiAgICBcclxuICAgIGhlaWdodDogMnB4ICFpbXBvcnRhbnQ7XHJcbiAgICB3aWR0aDogNTAwcHggIWltcG9ydGFudDtcclxuICAgIGJhY2tncm91bmQ6IHJnYigwLCAwLCAwKSAhaW1wb3J0YW50O1xyXG4gICAgZGlzcGxheTogYmxvY2sgIWltcG9ydGFudDtcclxuICAgIGZvbnQtc2l6ZTogMmVtICFpbXBvcnRhbnQ7XHJcbiAgICBvcGFjaXR5OiAxICFpbXBvcnRhbnQ7XHJcbiAgICB2aXNpYmlsaXR5OiB2aXNpYmxlICFpbXBvcnRhbnQ7XHJcblxyXG59XHJcbiNwcm9pdG1jYXJke1xyXG4gICAgYm9yZGVyOiAycHggc29saWQgZGFya2N5YW47XHJcbiAgICBib3JkZXItcmFkaXVzOiAzMHB4O1xyXG59Il19 */"

/***/ }),

/***/ "./src/app/produce-iteam-list/produce-iteam-list.page.ts":
/*!***************************************************************!*\
  !*** ./src/app/produce-iteam-list/produce-iteam-list.page.ts ***!
  \***************************************************************/
/*! exports provided: ProduceIteamListPage */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "ProduceIteamListPage", function() { return ProduceIteamListPage; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm5/core.js");
/* harmony import */ var _invantory_service__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ../invantory.service */ "./src/app/invantory.service.ts");



var ProduceIteamListPage = /** @class */ (function () {
    function ProduceIteamListPage(storage) {
        this.storage = storage;
    }
    ProduceIteamListPage.prototype.ngOnInit = function () {
        // this.storage.GetAllUsers().then((data: any) => {
        //   console.log(data);
        //   this.ListUser = data;
        // }, (error) => {
        //   console.log(error);
        // })
    };
    ProduceIteamListPage = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Component"])({
            selector: 'app-produce-iteam-list',
            template: __webpack_require__(/*! ./produce-iteam-list.page.html */ "./src/app/produce-iteam-list/produce-iteam-list.page.html"),
            styles: [__webpack_require__(/*! ./produce-iteam-list.page.scss */ "./src/app/produce-iteam-list/produce-iteam-list.page.scss")]
        }),
        tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"]("design:paramtypes", [_invantory_service__WEBPACK_IMPORTED_MODULE_2__["InvantoryService"]])
    ], ProduceIteamListPage);
    return ProduceIteamListPage;
}());



/***/ })

}]);
//# sourceMappingURL=produce-iteam-list-produce-iteam-list-module.js.map