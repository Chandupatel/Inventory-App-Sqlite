(window["webpackJsonp"] = window["webpackJsonp"] || []).push([["add-new-production-add-new-production-module"],{

/***/ "./src/app/add-new-production/add-new-production.module.ts":
/*!*****************************************************************!*\
  !*** ./src/app/add-new-production/add-new-production.module.ts ***!
  \*****************************************************************/
/*! exports provided: AddNewProductionPageModule */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "AddNewProductionPageModule", function() { return AddNewProductionPageModule; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm5/core.js");
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/common */ "./node_modules/@angular/common/fesm5/common.js");
/* harmony import */ var _angular_forms__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/forms */ "./node_modules/@angular/forms/fesm5/forms.js");
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @angular/router */ "./node_modules/@angular/router/fesm5/router.js");
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @ionic/angular */ "./node_modules/@ionic/angular/dist/fesm5.js");
/* harmony import */ var _add_new_production_page__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! ./add-new-production.page */ "./src/app/add-new-production/add-new-production.page.ts");







var routes = [
    {
        path: '',
        component: _add_new_production_page__WEBPACK_IMPORTED_MODULE_6__["AddNewProductionPage"]
    }
];
var AddNewProductionPageModule = /** @class */ (function () {
    function AddNewProductionPageModule() {
    }
    AddNewProductionPageModule = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["NgModule"])({
            imports: [
                _angular_common__WEBPACK_IMPORTED_MODULE_2__["CommonModule"],
                _angular_forms__WEBPACK_IMPORTED_MODULE_3__["FormsModule"],
                _ionic_angular__WEBPACK_IMPORTED_MODULE_5__["IonicModule"],
                _angular_router__WEBPACK_IMPORTED_MODULE_4__["RouterModule"].forChild(routes)
            ],
            declarations: [_add_new_production_page__WEBPACK_IMPORTED_MODULE_6__["AddNewProductionPage"]]
        })
    ], AddNewProductionPageModule);
    return AddNewProductionPageModule;
}());



/***/ }),

/***/ "./src/app/add-new-production/add-new-production.page.html":
/*!*****************************************************************!*\
  !*** ./src/app/add-new-production/add-new-production.page.html ***!
  \*****************************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = "\r\n\r\n<ion-content>\r\n    <ion-title>Add_New_Production</ion-title>\r\n    <hr>\r\n        <form >\r\n            <ion-row>\r\n                <ion-col size=\"12\">\r\n                    <ion-input placeholder=\"Enter Product Name\" id=\"Inputbox\" #pname></ion-input>\r\n                </ion-col>\r\n              </ion-row>\r\n              <ion-row>\r\n                  <ion-col size=\"12\">\r\n                      <ion-input placeholder=\"Enter ProductType\" id=\"Inputbox\" #ptype></ion-input>\r\n                  </ion-col>\r\n                </ion-row>\r\n                <ion-row>\r\n                    <ion-col size=\"6\">\r\n                        <ion-input placeholder=\"Enter Quantity\" id=\"Inputbox\" #pquntity></ion-input>\r\n                    </ion-col>\r\n                    <ion-col size=\"6\">\r\n                        <ion-list>\r\n                            <ion-item>\r\n                              <ion-select id=\"Inputbox1\" #punit>\r\n                                <ion-select-option value=\"1\">1</ion-select-option>\r\n                                <ion-select-option value=\"2\">2</ion-select-option>\r\n                                <ion-select-option value=\"3\">3</ion-select-option>\r\n                                <ion-select-option value=\"4\">4</ion-select-option>\r\n                              </ion-select>\r\n                            </ion-item>\r\n                          </ion-list>\r\n                    </ion-col>\r\n                  </ion-row>\r\n                  <ion-row>\r\n                      <ion-col size=\"12\">\r\n                          <ion-input placeholder=\"Enter Amount\" id=\"Inputbox\" #pamount></ion-input>\r\n                      </ion-col>\r\n                    </ion-row>\r\n                    <ion-row>\r\n                        <ion-col size=\"12\">\r\n                            <ion-input placeholder=\"Enter Date\" id=\"Inputbox\" type=\"date\" #pdate></ion-input>\r\n                        </ion-col>\r\n                      </ion-row>\r\n\r\n                    <ion-button color=\"danger\"(click)=\"Add_producation(pname.value,ptype.value,pquntity.value,punit.value,pamount.value,pdate.value)\">Add Production</ion-button>\r\n        </form>\r\n   \r\n</ion-content>\r\n"

/***/ }),

/***/ "./src/app/add-new-production/add-new-production.page.scss":
/*!*****************************************************************!*\
  !*** ./src/app/add-new-production/add-new-production.page.scss ***!
  \*****************************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = "hr {\n  height: 2px !important;\n  width: 500px !important;\n  background: black !important;\n  display: block !important;\n  font-size: 2em !important;\n  opacity: 1 !important;\n  visibility: visible !important; }\n\n#Inputbox {\n  border: 2px solid black; }\n\n#Inputbox1 {\n  border: 2px solid black;\n  width: 100%; }\n\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbInNyYy9hcHAvYWRkLW5ldy1wcm9kdWN0aW9uL0M6XFxVc2Vyc1xcQXZpbmFzaCBrdW5kYWxcXERlc2t0b3BcXEludmVudGFyeSBpb25pYyBhcHBcXEludmVudG9yeS9zcmNcXGFwcFxcYWRkLW5ldy1wcm9kdWN0aW9uXFxhZGQtbmV3LXByb2R1Y3Rpb24ucGFnZS5zY3NzIl0sIm5hbWVzIjpbXSwibWFwcGluZ3MiOiJBQUFBO0VBRUksc0JBQXNCO0VBQ3RCLHVCQUF1QjtFQUN2Qiw0QkFBbUM7RUFDbkMseUJBQXlCO0VBQ3pCLHlCQUF5QjtFQUN6QixxQkFBcUI7RUFDckIsOEJBQThCLEVBQUE7O0FBR2xDO0VBQ0ksdUJBQXVCLEVBQUE7O0FBRTNCO0VBQ0ksdUJBQXVCO0VBQ3ZCLFdBQVcsRUFBQSIsImZpbGUiOiJzcmMvYXBwL2FkZC1uZXctcHJvZHVjdGlvbi9hZGQtbmV3LXByb2R1Y3Rpb24ucGFnZS5zY3NzIiwic291cmNlc0NvbnRlbnQiOlsiaHJ7XHJcbiAgICBcclxuICAgIGhlaWdodDogMnB4ICFpbXBvcnRhbnQ7XHJcbiAgICB3aWR0aDogNTAwcHggIWltcG9ydGFudDtcclxuICAgIGJhY2tncm91bmQ6IHJnYigwLCAwLCAwKSAhaW1wb3J0YW50O1xyXG4gICAgZGlzcGxheTogYmxvY2sgIWltcG9ydGFudDtcclxuICAgIGZvbnQtc2l6ZTogMmVtICFpbXBvcnRhbnQ7XHJcbiAgICBvcGFjaXR5OiAxICFpbXBvcnRhbnQ7XHJcbiAgICB2aXNpYmlsaXR5OiB2aXNpYmxlICFpbXBvcnRhbnQ7XHJcblxyXG59XHJcbiNJbnB1dGJveHtcclxuICAgIGJvcmRlcjogMnB4IHNvbGlkIGJsYWNrO1xyXG59XHJcbiNJbnB1dGJveDF7XHJcbiAgICBib3JkZXI6IDJweCBzb2xpZCBibGFjaztcclxuICAgIHdpZHRoOiAxMDAlO1xyXG59Il19 */"

/***/ }),

/***/ "./src/app/add-new-production/add-new-production.page.ts":
/*!***************************************************************!*\
  !*** ./src/app/add-new-production/add-new-production.page.ts ***!
  \***************************************************************/
/*! exports provided: AddNewProductionPage */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "AddNewProductionPage", function() { return AddNewProductionPage; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm5/core.js");
/* harmony import */ var _invantory_service__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ../invantory.service */ "./src/app/invantory.service.ts");



var AddNewProductionPage = /** @class */ (function () {
    function AddNewProductionPage(storage) {
        this.storage = storage;
    }
    AddNewProductionPage.prototype.Add_producation = function (a, b, c, d, e, f) {
        /*  console.log(b);
         console.log(c);
         console.log(d);
         console.log(e);
         console.log(f); */
        //   this.storage.CreateUser(a,b,c,d,e,f).then( (data) => {
        //     console.log(data);
        //   },(error) =>{
        //    console.log(error);
        // })
    };
    AddNewProductionPage.prototype.ngOnInit = function () {
    };
    AddNewProductionPage = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Component"])({
            selector: 'app-add-new-production',
            template: __webpack_require__(/*! ./add-new-production.page.html */ "./src/app/add-new-production/add-new-production.page.html"),
            styles: [__webpack_require__(/*! ./add-new-production.page.scss */ "./src/app/add-new-production/add-new-production.page.scss")]
        }),
        tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"]("design:paramtypes", [_invantory_service__WEBPACK_IMPORTED_MODULE_2__["InvantoryService"]])
    ], AddNewProductionPage);
    return AddNewProductionPage;
}());



/***/ })

}]);
//# sourceMappingURL=add-new-production-add-new-production-module.js.map