(window["webpackJsonp"] = window["webpackJsonp"] || []).push([["stock-details-stock-details-module"],{

/***/ "./src/app/stock-details/stock-details.module.ts":
/*!*******************************************************!*\
  !*** ./src/app/stock-details/stock-details.module.ts ***!
  \*******************************************************/
/*! exports provided: StockDetailsPageModule */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "StockDetailsPageModule", function() { return StockDetailsPageModule; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm5/core.js");
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/common */ "./node_modules/@angular/common/fesm5/common.js");
/* harmony import */ var _angular_forms__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/forms */ "./node_modules/@angular/forms/fesm5/forms.js");
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @angular/router */ "./node_modules/@angular/router/fesm5/router.js");
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @ionic/angular */ "./node_modules/@ionic/angular/dist/fesm5.js");
/* harmony import */ var _stock_details_page__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! ./stock-details.page */ "./src/app/stock-details/stock-details.page.ts");







var routes = [
    {
        path: '',
        component: _stock_details_page__WEBPACK_IMPORTED_MODULE_6__["StockDetailsPage"]
    }
];
var StockDetailsPageModule = /** @class */ (function () {
    function StockDetailsPageModule() {
    }
    StockDetailsPageModule = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["NgModule"])({
            imports: [
                _angular_common__WEBPACK_IMPORTED_MODULE_2__["CommonModule"],
                _angular_forms__WEBPACK_IMPORTED_MODULE_3__["FormsModule"],
                _ionic_angular__WEBPACK_IMPORTED_MODULE_5__["IonicModule"],
                _angular_router__WEBPACK_IMPORTED_MODULE_4__["RouterModule"].forChild(routes)
            ],
            declarations: [_stock_details_page__WEBPACK_IMPORTED_MODULE_6__["StockDetailsPage"]]
        })
    ], StockDetailsPageModule);
    return StockDetailsPageModule;
}());



/***/ }),

/***/ "./src/app/stock-details/stock-details.page.html":
/*!*******************************************************!*\
  !*** ./src/app/stock-details/stock-details.page.html ***!
  \*******************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = "<ion-header>\r\n    <ion-toolbar>\r\n      <ion-title class=\"title\">Stock Item Details</ion-title>\r\n    </ion-toolbar>\r\n  </ion-header>\r\n  \r\n  <ion-content class=\"primary\">\r\n    <br>\r\n      <div>  \r\n        <b><ion-label style=\"font-family:-apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, Oxygen, Ubuntu, Cantarell, 'Open Sans', 'Helvetica Neue', sans-serif; margin-left: 75px;font-size: 25px;\">\r\n         Item Type\r\n        </ion-label></b>\r\n              </div> \r\n              <br>\r\n      <ion-card class = \"card1\">\r\n          \r\n              \r\n              <ion-item lines=\"none\">\r\n                 <ion-icon name=\"cart\" slot=\"start\" style=\"font-size: 20px;\"></ion-icon>\r\n                  <ion-label  slot=\"start\" style=\"margin-left: -20px;\">Item Name: </ion-label>\r\n                 \r\n                </ion-item>\r\n                <ion-item>\r\n                    <ion-icon name=\"logo-usd\" slot=\"start\" style=\"font-size: 20px;\"></ion-icon>\r\n                    <ion-label  slot=\"start\" style=\"margin-left: -20px;\">Prize: </ion-label>\r\n                </ion-item>\r\n          \r\n        </ion-card>\r\n        <ion-card class = \"card2\" >\r\n            <ion-item lines=\"none\">\r\n                <ion-icon name=\"cart\" slot=\"start\" style=\"font-size: 20px;\"></ion-icon>\r\n                <ion-label  slot=\"start\" style=\"margin-left: -20px;\">Item Name: </ion-label>\r\n               \r\n              </ion-item>\r\n              <ion-item>\r\n                  <ion-icon name=\"logo-usd\" slot=\"start\" style=\"font-size: 20px;\"></ion-icon>\r\n                  <ion-label  slot=\"start\" style=\"margin-left: -20px;\">Prize: </ion-label>\r\n              </ion-item>\r\n          </ion-card>\r\n          <ion-card class = \"card3\">\r\n              <ion-item lines=\"none\">\r\n                  <ion-icon name=\"cart\" slot=\"start\" style=\"font-size: 20px;\"></ion-icon>\r\n                  <ion-label  slot=\"start\" style=\"margin-left: -20px;\">Item Name: </ion-label>\r\n                </ion-item>\r\n                <ion-item>\r\n                    <ion-icon name=\"logo-usd\" slot=\"start\" style=\"font-size: 20px;\"></ion-icon>\r\n                    <ion-label  slot=\"start\" style=\"margin-left: -20px;\">Prize: </ion-label>\r\n                   \r\n                </ion-item>\r\n            </ion-card>\r\n            \r\n                   \r\n  </ion-content>\r\n  \r\n  \r\n"

/***/ }),

/***/ "./src/app/stock-details/stock-details.page.scss":
/*!*******************************************************!*\
  !*** ./src/app/stock-details/stock-details.page.scss ***!
  \*******************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = ".card1 {\n  border: 2px solid;\n  border-color: blue;\n  border-radius: 20px;\n  font-family: 'Times New Roman', Times, serif;\n  font-size: 20px; }\n\n.card2 {\n  border: 2px solid;\n  border-color: blue;\n  border-radius: 25px; }\n\n.card3 {\n  border: 2px solid;\n  border-color: blue;\n  border-radius: 25px; }\n\n.title {\n  font-family: cursive;\n  font-size: 25px;\n  margin-left: 70px; }\n\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbInNyYy9hcHAvc3RvY2stZGV0YWlscy9DOlxcVXNlcnNcXEF2aW5hc2gga3VuZGFsXFxEZXNrdG9wXFxJbnZlbnRhcnkgaW9uaWMgYXBwXFxJbnZlbnRvcnkvc3JjXFxhcHBcXHN0b2NrLWRldGFpbHNcXHN0b2NrLWRldGFpbHMucGFnZS5zY3NzIl0sIm5hbWVzIjpbXSwibWFwcGluZ3MiOiJBQUFBO0VBQ0ksaUJBQWtCO0VBQ2xCLGtCQUFpQjtFQUNqQixtQkFBbUI7RUFDbkIsNENBQTRDO0VBQzVDLGVBQWUsRUFBQTs7QUFHbkI7RUFDSSxpQkFBa0I7RUFDbEIsa0JBQWlCO0VBQ2pCLG1CQUFtQixFQUFBOztBQUV2QjtFQUNJLGlCQUFrQjtFQUNsQixrQkFBaUI7RUFDakIsbUJBQW1CLEVBQUE7O0FBRXZCO0VBQ0ksb0JBQW9CO0VBQ3BCLGVBQWU7RUFDZixpQkFBaUIsRUFBQSIsImZpbGUiOiJzcmMvYXBwL3N0b2NrLWRldGFpbHMvc3RvY2stZGV0YWlscy5wYWdlLnNjc3MiLCJzb3VyY2VzQ29udGVudCI6WyIuY2FyZDEge1xyXG4gICAgYm9yZGVyOiAycHggc29saWQgO1xyXG4gICAgYm9yZGVyLWNvbG9yOmJsdWU7XHJcbiAgICBib3JkZXItcmFkaXVzOiAyMHB4O1xyXG4gICAgZm9udC1mYW1pbHk6ICdUaW1lcyBOZXcgUm9tYW4nLCBUaW1lcywgc2VyaWY7XHJcbiAgICBmb250LXNpemU6IDIwcHg7XHJcbiB9XHJcblxyXG4uY2FyZDIge1xyXG4gICAgYm9yZGVyOiAycHggc29saWQgO1xyXG4gICAgYm9yZGVyLWNvbG9yOmJsdWU7XHJcbiAgICBib3JkZXItcmFkaXVzOiAyNXB4O1xyXG4gfVxyXG4uY2FyZDMge1xyXG4gICAgYm9yZGVyOiAycHggc29saWQgO1xyXG4gICAgYm9yZGVyLWNvbG9yOmJsdWU7XHJcbiAgICBib3JkZXItcmFkaXVzOiAyNXB4O1xyXG4gfVxyXG4udGl0bGV7XHJcbiAgICBmb250LWZhbWlseTogY3Vyc2l2ZTtcclxuICAgIGZvbnQtc2l6ZTogMjVweDtcclxuICAgIG1hcmdpbi1sZWZ0OiA3MHB4O1xyXG59Il19 */"

/***/ }),

/***/ "./src/app/stock-details/stock-details.page.ts":
/*!*****************************************************!*\
  !*** ./src/app/stock-details/stock-details.page.ts ***!
  \*****************************************************/
/*! exports provided: StockDetailsPage */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "StockDetailsPage", function() { return StockDetailsPage; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm5/core.js");


var StockDetailsPage = /** @class */ (function () {
    function StockDetailsPage() {
    }
    StockDetailsPage.prototype.ngOnInit = function () {
    };
    StockDetailsPage = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Component"])({
            selector: 'app-stock-details',
            template: __webpack_require__(/*! ./stock-details.page.html */ "./src/app/stock-details/stock-details.page.html"),
            styles: [__webpack_require__(/*! ./stock-details.page.scss */ "./src/app/stock-details/stock-details.page.scss")]
        }),
        tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"]("design:paramtypes", [])
    ], StockDetailsPage);
    return StockDetailsPage;
}());



/***/ })

}]);
//# sourceMappingURL=stock-details-stock-details-module.js.map