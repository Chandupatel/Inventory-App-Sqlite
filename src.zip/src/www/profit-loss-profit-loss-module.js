(window["webpackJsonp"] = window["webpackJsonp"] || []).push([["profit-loss-profit-loss-module"],{

/***/ "./src/app/profit-loss/profit-loss.module.ts":
/*!***************************************************!*\
  !*** ./src/app/profit-loss/profit-loss.module.ts ***!
  \***************************************************/
/*! exports provided: ProfitLossPageModule */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "ProfitLossPageModule", function() { return ProfitLossPageModule; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm5/core.js");
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/common */ "./node_modules/@angular/common/fesm5/common.js");
/* harmony import */ var _angular_forms__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/forms */ "./node_modules/@angular/forms/fesm5/forms.js");
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @angular/router */ "./node_modules/@angular/router/fesm5/router.js");
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @ionic/angular */ "./node_modules/@ionic/angular/dist/fesm5.js");
/* harmony import */ var _profit_loss_page__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! ./profit-loss.page */ "./src/app/profit-loss/profit-loss.page.ts");







var routes = [
    {
        path: '',
        component: _profit_loss_page__WEBPACK_IMPORTED_MODULE_6__["ProfitLossPage"]
    }
];
var ProfitLossPageModule = /** @class */ (function () {
    function ProfitLossPageModule() {
    }
    ProfitLossPageModule = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["NgModule"])({
            imports: [
                _angular_common__WEBPACK_IMPORTED_MODULE_2__["CommonModule"],
                _angular_forms__WEBPACK_IMPORTED_MODULE_3__["FormsModule"],
                _ionic_angular__WEBPACK_IMPORTED_MODULE_5__["IonicModule"],
                _angular_router__WEBPACK_IMPORTED_MODULE_4__["RouterModule"].forChild(routes)
            ],
            declarations: [_profit_loss_page__WEBPACK_IMPORTED_MODULE_6__["ProfitLossPage"]]
        })
    ], ProfitLossPageModule);
    return ProfitLossPageModule;
}());



/***/ }),

/***/ "./src/app/profit-loss/profit-loss.page.html":
/*!***************************************************!*\
  !*** ./src/app/profit-loss/profit-loss.page.html ***!
  \***************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = "<ion-header>\n \n  <ion-row>\n <ion-title>For Profit and Loss</ion-title>\n <!-- <ion-icon class=\"ion\" name=\"contact\"></ion-icon> -->\n <a routerLink=\"/home\" ><ion-icon class=\"ion\" name=\"home\" ></ion-icon></a>\n\n\n</ion-row>\n \n\n\n</ion-header>\n\n<ion-content>\n<ion-row>\n\n <ion-label><b>Select Date</b></ion-label><br>\n <!-- <ion-datetime  placeholder=\"Select Date\"></ion-datetime> -->\n<ion-input type=\"date\" class=\"input1\"></ion-input><br>\n<ion-input type=\"date\" class=\"input2\"></ion-input>\n<ion-button color=\"danger\" (click)=\"go()\">Go</ion-button>\n\n\n</ion-row>\n</ion-content>\n"

/***/ }),

/***/ "./src/app/profit-loss/profit-loss.page.scss":
/*!***************************************************!*\
  !*** ./src/app/profit-loss/profit-loss.page.scss ***!
  \***************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = "ion-title {\n  font-size: 120%;\n  color: #af2525;\n  margin-left: 18%;\n  margin-top: 6%;\n  margin-right: 2px; }\n\nion-icon {\n  font-size: 150%;\n  margin-right: 30px;\n  margin-top: 20px;\n  color: black; }\n\nion-header {\n  height: 10%; }\n\nion-label {\n  margin-left: 25%;\n  margin-top: 10%;\n  font-size: 20px; }\n\n.input1 {\n  border: 2px solid;\n  margin-right: 15%;\n  margin-top: 10%;\n  margin-left: 10%;\n  width: 100px; }\n\n.input2 {\n  border: 2px solid;\n  margin-right: 15%;\n  margin-top: 5%;\n  margin-left: 10%;\n  width: 100px; }\n\nion-button {\n  margin-left: 12%;\n  margin-top: 20%;\n  color: black;\n  width: 70%; }\n\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbInNyYy9hcHAvcHJvZml0LWxvc3MvQzpcXFVzZXJzXFxBdmluYXNoIGt1bmRhbFxcRGVza3RvcFxcSW52ZW50YXJ5IGlvbmljIGFwcFxcSW52ZW50b3J5L3NyY1xcYXBwXFxwcm9maXQtbG9zc1xccHJvZml0LWxvc3MucGFnZS5zY3NzIl0sIm5hbWVzIjpbXSwibWFwcGluZ3MiOiJBQUFBO0VBQ0ksZUFBZTtFQUNmLGNBQXNCO0VBQ3RCLGdCQUFlO0VBRWYsY0FBYTtFQUNiLGlCQUFnQixFQUFBOztBQVFwQjtFQUNJLGVBQWM7RUFDZCxrQkFBaUI7RUFDakIsZ0JBQWU7RUFDZixZQUFXLEVBQUE7O0FBRWQ7RUFDSSxXQUFVLEVBQUE7O0FBRWQ7RUFDSSxnQkFBZTtFQUNmLGVBQWM7RUFDZCxlQUFlLEVBQUE7O0FBR3BCO0VBRUksaUJBQWlCO0VBQ2pCLGlCQUFpQjtFQUNqQixlQUFjO0VBQ2QsZ0JBQWU7RUFDZixZQUFXLEVBQUE7O0FBRWQ7RUFFRyxpQkFBaUI7RUFDakIsaUJBQWlCO0VBQ2hCLGNBQWE7RUFDZCxnQkFBZTtFQUNmLFlBQVcsRUFBQTs7QUFFZDtFQUNJLGdCQUFlO0VBQ2YsZUFBYztFQUNqQixZQUFXO0VBQ1gsVUFBUyxFQUFBIiwiZmlsZSI6InNyYy9hcHAvcHJvZml0LWxvc3MvcHJvZml0LWxvc3MucGFnZS5zY3NzIiwic291cmNlc0NvbnRlbnQiOlsiaW9uLXRpdGxle1xyXG4gICAgZm9udC1zaXplOiAxMjAlO1xyXG4gICAgY29sb3I6cmdiKDE3NSwgMzcsIDM3KTtcclxuICAgIG1hcmdpbi1sZWZ0OjE4JTtcclxuICAgIC8vZm9udC1mYW1pbHk6IGN1cnNpdmU7XHJcbiAgICBtYXJnaW4tdG9wOjYlO1xyXG4gICAgbWFyZ2luLXJpZ2h0OjJweDsgIFxyXG59XHJcbi8vICNidXR0b257XHJcbi8vICAgICB3aWR0aDogMTBweDtcclxuLy8gICAgIGhlaWdodDoxMHB4O1xyXG4vLyAgICAgbWFyZ2luLXJpZ2h0OjMwcHg7XHJcbi8vICAgICBtYXJnaW4tdG9wOjIwcHg7XHJcbi8vIH1cclxuaW9uLWljb257XHJcbiAgICBmb250LXNpemU6MTUwJTtcclxuICAgIG1hcmdpbi1yaWdodDozMHB4O1xyXG4gICAgbWFyZ2luLXRvcDoyMHB4O1xyXG4gICAgY29sb3I6YmxhY2s7XHJcbn1cclxuIGlvbi1oZWFkZXJ7XHJcbiAgICAgaGVpZ2h0OjEwJTtcclxuIH1cclxuIGlvbi1sYWJlbHtcclxuICAgICBtYXJnaW4tbGVmdDoyNSU7XHJcbiAgICAgbWFyZ2luLXRvcDoxMCU7XHJcbiAgICAgZm9udC1zaXplOiAyMHB4O1xyXG4gICAgXHJcbiB9XHJcbi5pbnB1dDF7XHJcbiAgIFxyXG4gICAgYm9yZGVyOiAycHggc29saWQ7XHJcbiAgICBtYXJnaW4tcmlnaHQ6IDE1JTtcclxuICAgIG1hcmdpbi10b3A6MTAlO1xyXG4gICAgbWFyZ2luLWxlZnQ6MTAlO1xyXG4gICAgd2lkdGg6MTAwcHg7XHJcbiB9XHJcbiAuaW5wdXQye1xyXG4gICBcclxuICAgIGJvcmRlcjogMnB4IHNvbGlkO1xyXG4gICAgbWFyZ2luLXJpZ2h0OiAxNSU7XHJcbiAgICAgbWFyZ2luLXRvcDo1JTtcclxuICAgIG1hcmdpbi1sZWZ0OjEwJTtcclxuICAgIHdpZHRoOjEwMHB4O1xyXG4gfVxyXG4gaW9uLWJ1dHRvbntcclxuICAgICBtYXJnaW4tbGVmdDoxMiU7XHJcbiAgICAgbWFyZ2luLXRvcDoyMCU7XHJcbiAgY29sb3I6YmxhY2s7XHJcbiAgd2lkdGg6NzAlO1xyXG4gXHJcbiAvLyBib3JkZXItcmFkaXVzOiA1MCU7XHJcbn0iXX0= */"

/***/ }),

/***/ "./src/app/profit-loss/profit-loss.page.ts":
/*!*************************************************!*\
  !*** ./src/app/profit-loss/profit-loss.page.ts ***!
  \*************************************************/
/*! exports provided: ProfitLossPage */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "ProfitLossPage", function() { return ProfitLossPage; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm5/core.js");
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/router */ "./node_modules/@angular/router/fesm5/router.js");



var ProfitLossPage = /** @class */ (function () {
    function ProfitLossPage(router) {
        this.router = router;
    }
    ProfitLossPage.prototype.go = function () {
        this.router.navigate(['/profit-loss-status']);
    };
    ProfitLossPage.prototype.ngOnInit = function () {
    };
    ProfitLossPage = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Component"])({
            selector: 'app-profit-loss',
            template: __webpack_require__(/*! ./profit-loss.page.html */ "./src/app/profit-loss/profit-loss.page.html"),
            styles: [__webpack_require__(/*! ./profit-loss.page.scss */ "./src/app/profit-loss/profit-loss.page.scss")]
        }),
        tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"]("design:paramtypes", [_angular_router__WEBPACK_IMPORTED_MODULE_2__["Router"]])
    ], ProfitLossPage);
    return ProfitLossPage;
}());



/***/ })

}]);
//# sourceMappingURL=profit-loss-profit-loss-module.js.map