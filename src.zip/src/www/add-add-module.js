(window["webpackJsonp"] = window["webpackJsonp"] || []).push([["add-add-module"],{

/***/ "./src/app/add/add.module.ts":
/*!***********************************!*\
  !*** ./src/app/add/add.module.ts ***!
  \***********************************/
/*! exports provided: AddPageModule */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "AddPageModule", function() { return AddPageModule; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm5/core.js");
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/common */ "./node_modules/@angular/common/fesm5/common.js");
/* harmony import */ var _angular_forms__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/forms */ "./node_modules/@angular/forms/fesm5/forms.js");
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @angular/router */ "./node_modules/@angular/router/fesm5/router.js");
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @ionic/angular */ "./node_modules/@ionic/angular/dist/fesm5.js");
/* harmony import */ var _add_page__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! ./add.page */ "./src/app/add/add.page.ts");







var routes = [
    {
        path: '',
        component: _add_page__WEBPACK_IMPORTED_MODULE_6__["AddPage"]
    }
];
var AddPageModule = /** @class */ (function () {
    function AddPageModule() {
    }
    AddPageModule = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["NgModule"])({
            imports: [
                _angular_common__WEBPACK_IMPORTED_MODULE_2__["CommonModule"],
                _angular_forms__WEBPACK_IMPORTED_MODULE_3__["FormsModule"],
                _ionic_angular__WEBPACK_IMPORTED_MODULE_5__["IonicModule"],
                _angular_router__WEBPACK_IMPORTED_MODULE_4__["RouterModule"].forChild(routes)
            ],
            declarations: [_add_page__WEBPACK_IMPORTED_MODULE_6__["AddPage"]]
        })
    ], AddPageModule);
    return AddPageModule;
}());



/***/ }),

/***/ "./src/app/add/add.page.html":
/*!***********************************!*\
  !*** ./src/app/add/add.page.html ***!
  \***********************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = "<ion-header>\r\n  <ion-toolbar>\r\n    <ion-title style=\"text-align:center\">\r\n      Add Employee\r\n    </ion-title>\r\n  </ion-toolbar>\r\n</ion-header>\r\n\r\n<ion-content>\r\n  <div class=\"ion-padding\">\r\n      <ion-item>\r\n          <ion-input placeholder=\"Employee Name\" #ename></ion-input>\r\n        </ion-item>\r\n        <br> <br>\r\n        <ion-item>\r\n            <ion-input placeholder=\"Contact\" #econtact></ion-input>\r\n          </ion-item>\r\n          <br> <br>\r\n          <ion-item>\r\n              <ion-input placeholder=\"Email Id\" #email></ion-input>\r\n            </ion-item>\r\n            <br> <br>\r\n            <ion-item>\r\n                <ion-input placeholder=\"Salary\" #esalary></ion-input>\r\n              </ion-item>\r\n              <br> <br>\r\n              <ion-select value=\"Mode\" okText=\"Okay\" cancelText=\"Dismiss\" #emode>\r\n                  <ion-select-option value=\"Mode\" disabled>Mode</ion-select-option>\r\n                  <ion-select-option value=\"blonde\">Blonde</ion-select-option>\r\n                  <ion-select-option value=\"black\">Black</ion-select-option>\r\n                  <ion-select-option value=\"red\">Red</ion-select-option>\r\n                </ion-select>\r\n                <br> <br>\r\n                <ion-item>\r\n                    <ion-textarea placeholder=\"Address\" #eaddress></ion-textarea>\r\n                  </ion-item>\r\n                  <br> <br> <br>\r\n                  <a href=\"/view\"><ion-button color=\"success\" expand=\"block\" (click)=\"Add_employee(ename.value,econtact.value,email.value,esalary.value,emode.value,eaddress.value)\">Add</ion-button></a>\r\n  </div>\r\n</ion-content>\r\n"

/***/ }),

/***/ "./src/app/add/add.page.scss":
/*!***********************************!*\
  !*** ./src/app/add/add.page.scss ***!
  \***********************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = "ion-item {\n  border: 2px solid gray; }\n\nion-select {\n  border: 2px solid gray; }\n\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbInNyYy9hcHAvYWRkL0M6XFxVc2Vyc1xcQXZpbmFzaCBrdW5kYWxcXERlc2t0b3BcXEludmVudGFyeSBpb25pYyBhcHBcXEludmVudG9yeS9zcmNcXGFwcFxcYWRkXFxhZGQucGFnZS5zY3NzIl0sIm5hbWVzIjpbXSwibWFwcGluZ3MiOiJBQUFBO0VBQ0ksc0JBQXNCLEVBQUE7O0FBRzFCO0VBQ0ksc0JBQXNCLEVBQUEiLCJmaWxlIjoic3JjL2FwcC9hZGQvYWRkLnBhZ2Uuc2NzcyIsInNvdXJjZXNDb250ZW50IjpbImlvbi1pdGVte1xyXG4gICAgYm9yZGVyOiAycHggc29saWQgZ3JheTtcclxufVxyXG5cclxuaW9uLXNlbGVjdHtcclxuICAgIGJvcmRlcjogMnB4IHNvbGlkIGdyYXk7XHJcblxyXG59Il19 */"

/***/ }),

/***/ "./src/app/add/add.page.ts":
/*!*********************************!*\
  !*** ./src/app/add/add.page.ts ***!
  \*********************************/
/*! exports provided: AddPage */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "AddPage", function() { return AddPage; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm5/core.js");
/* harmony import */ var _invantory_service__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ../invantory.service */ "./src/app/invantory.service.ts");



var AddPage = /** @class */ (function () {
    function AddPage(storage) {
        this.storage = storage;
    }
    // Add_employee(a,b,c,d,e,f){
    //   this.storage.CreateUser(a,b,c,d,e,f).then((data)=>{
    //     console.log(data);
    //   },(error)=>{
    //     console.log(error);
    //   })
    // }
    AddPage.prototype.ngOnInit = function () {
    };
    AddPage = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Component"])({
            selector: 'app-add',
            template: __webpack_require__(/*! ./add.page.html */ "./src/app/add/add.page.html"),
            styles: [__webpack_require__(/*! ./add.page.scss */ "./src/app/add/add.page.scss")]
        }),
        tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"]("design:paramtypes", [_invantory_service__WEBPACK_IMPORTED_MODULE_2__["InvantoryService"]])
    ], AddPage);
    return AddPage;
}());



/***/ })

}]);
//# sourceMappingURL=add-add-module.js.map