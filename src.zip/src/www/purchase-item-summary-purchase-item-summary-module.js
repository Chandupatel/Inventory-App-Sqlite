(window["webpackJsonp"] = window["webpackJsonp"] || []).push([["purchase-item-summary-purchase-item-summary-module"],{

/***/ "./src/app/purchase-item-summary/purchase-item-summary.module.ts":
/*!***********************************************************************!*\
  !*** ./src/app/purchase-item-summary/purchase-item-summary.module.ts ***!
  \***********************************************************************/
/*! exports provided: PurchaseItemSummaryPageModule */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "PurchaseItemSummaryPageModule", function() { return PurchaseItemSummaryPageModule; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm5/core.js");
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/common */ "./node_modules/@angular/common/fesm5/common.js");
/* harmony import */ var _angular_forms__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/forms */ "./node_modules/@angular/forms/fesm5/forms.js");
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @angular/router */ "./node_modules/@angular/router/fesm5/router.js");
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @ionic/angular */ "./node_modules/@ionic/angular/dist/fesm5.js");
/* harmony import */ var _purchase_item_summary_page__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! ./purchase-item-summary.page */ "./src/app/purchase-item-summary/purchase-item-summary.page.ts");







var routes = [
    {
        path: '',
        component: _purchase_item_summary_page__WEBPACK_IMPORTED_MODULE_6__["PurchaseItemSummaryPage"]
    }
];
var PurchaseItemSummaryPageModule = /** @class */ (function () {
    function PurchaseItemSummaryPageModule() {
    }
    PurchaseItemSummaryPageModule = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["NgModule"])({
            imports: [
                _angular_common__WEBPACK_IMPORTED_MODULE_2__["CommonModule"],
                _angular_forms__WEBPACK_IMPORTED_MODULE_3__["FormsModule"],
                _ionic_angular__WEBPACK_IMPORTED_MODULE_5__["IonicModule"],
                _angular_router__WEBPACK_IMPORTED_MODULE_4__["RouterModule"].forChild(routes)
            ],
            declarations: [_purchase_item_summary_page__WEBPACK_IMPORTED_MODULE_6__["PurchaseItemSummaryPage"]]
        })
    ], PurchaseItemSummaryPageModule);
    return PurchaseItemSummaryPageModule;
}());



/***/ }),

/***/ "./src/app/purchase-item-summary/purchase-item-summary.page.html":
/*!***********************************************************************!*\
  !*** ./src/app/purchase-item-summary/purchase-item-summary.page.html ***!
  \***********************************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = "<ion-header>\r\n  <ion-toolbar>\r\n    <ion-title>Purchase_Item_Summary</ion-title>\r\n  </ion-toolbar>\r\n</ion-header>\r\n\r\n<ion-content>\r\n\r\n</ion-content>\r\n"

/***/ }),

/***/ "./src/app/purchase-item-summary/purchase-item-summary.page.scss":
/*!***********************************************************************!*\
  !*** ./src/app/purchase-item-summary/purchase-item-summary.page.scss ***!
  \***********************************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = "\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IiIsImZpbGUiOiJzcmMvYXBwL3B1cmNoYXNlLWl0ZW0tc3VtbWFyeS9wdXJjaGFzZS1pdGVtLXN1bW1hcnkucGFnZS5zY3NzIn0= */"

/***/ }),

/***/ "./src/app/purchase-item-summary/purchase-item-summary.page.ts":
/*!*********************************************************************!*\
  !*** ./src/app/purchase-item-summary/purchase-item-summary.page.ts ***!
  \*********************************************************************/
/*! exports provided: PurchaseItemSummaryPage */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "PurchaseItemSummaryPage", function() { return PurchaseItemSummaryPage; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm5/core.js");


var PurchaseItemSummaryPage = /** @class */ (function () {
    function PurchaseItemSummaryPage() {
    }
    PurchaseItemSummaryPage.prototype.ngOnInit = function () {
    };
    PurchaseItemSummaryPage = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Component"])({
            selector: 'app-purchase-item-summary',
            template: __webpack_require__(/*! ./purchase-item-summary.page.html */ "./src/app/purchase-item-summary/purchase-item-summary.page.html"),
            styles: [__webpack_require__(/*! ./purchase-item-summary.page.scss */ "./src/app/purchase-item-summary/purchase-item-summary.page.scss")]
        }),
        tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"]("design:paramtypes", [])
    ], PurchaseItemSummaryPage);
    return PurchaseItemSummaryPage;
}());



/***/ })

}]);
//# sourceMappingURL=purchase-item-summary-purchase-item-summary-module.js.map