(window["webpackJsonp"] = window["webpackJsonp"] || []).push([["home-home-module"],{

/***/ "./src/app/home/home.module.ts":
/*!*************************************!*\
  !*** ./src/app/home/home.module.ts ***!
  \*************************************/
/*! exports provided: HomePageModule */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "HomePageModule", function() { return HomePageModule; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm5/core.js");
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/common */ "./node_modules/@angular/common/fesm5/common.js");
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @ionic/angular */ "./node_modules/@ionic/angular/dist/fesm5.js");
/* harmony import */ var _angular_forms__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @angular/forms */ "./node_modules/@angular/forms/fesm5/forms.js");
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @angular/router */ "./node_modules/@angular/router/fesm5/router.js");
/* harmony import */ var _home_page__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! ./home.page */ "./src/app/home/home.page.ts");







var HomePageModule = /** @class */ (function () {
    function HomePageModule() {
    }
    HomePageModule = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["NgModule"])({
            imports: [
                _angular_common__WEBPACK_IMPORTED_MODULE_2__["CommonModule"],
                _angular_forms__WEBPACK_IMPORTED_MODULE_4__["FormsModule"],
                _ionic_angular__WEBPACK_IMPORTED_MODULE_3__["IonicModule"],
                _angular_router__WEBPACK_IMPORTED_MODULE_5__["RouterModule"].forChild([
                    {
                        path: '',
                        component: _home_page__WEBPACK_IMPORTED_MODULE_6__["HomePage"]
                    }
                ])
            ],
            declarations: [_home_page__WEBPACK_IMPORTED_MODULE_6__["HomePage"]]
        })
    ], HomePageModule);
    return HomePageModule;
}());



/***/ }),

/***/ "./src/app/home/home.page.html":
/*!*************************************!*\
  !*** ./src/app/home/home.page.html ***!
  \*************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = "\r\n\r\n<ion-content>\r\n   <!--  <ion-row>\r\n        <ion-col size=\"2\">\r\n        </ion-col>\r\n        <ion-col size=\"8\">\r\n            <ion-button shape=\"round\" color=\"danger\" id=\"Dlp\" expand=\"full\" routerLink=\"/produce-iteam-list\" >Daily Production</ion-button>\r\n          </ion-col>\r\n          <ion-col size=\"2\">\r\n            </ion-col>\r\n      </ion-row> -->\r\n  \r\n\r\n<!-- <ion-header>\r\n  <ion-toolbar>\r\n    <ion-title>\r\n      Company Name\r\n    </ion-title>\r\n  </ion-toolbar>\r\n</ion-header> -->\r\n<ion-content >\r\n  <ion-row>\r\n    <ion-col id=\"column\">\r\n      <label >Company Name</label>\r\n    </ion-col>\r\n  </ion-row>\r\n  <hr>\r\n    <ion-row>\r\n    <ion-col size=\"6\" id=\"column1\">\r\n        <a routerLink=\"/purchaseitem\"><ion-button color=\"light\" shape=\"round\" id =\"button\"><ion-icon name=\"add-circle\"></ion-icon></ion-button></a>\r\n        <br>\r\n        <label id =\"label1\">Inventary Management</label>\r\n    </ion-col>\r\n    <ion-col size=\"6\" id=\"column1\">\r\n        <a href=\"/list\"><ion-button color=\"light\" shape=\"round\" id =\"button\"><ion-icon name=\"add-circle\"></ion-icon></ion-button> </a>\r\n        <br>\r\n        <label id =\"label1\">Employee Management</label>\r\n      </ion-col>\r\n    </ion-row>\r\n    <ion-row>\r\n      <ion-col size=\"6\" id=\"column1\">\r\n        <a routerLink=\"/produce-iteam-list\"  ><ion-button color=\"light\" shape=\"round\" id =\"button\"><ion-icon name=\"add-circle\"  ></ion-icon></ion-button>\r\n        </a> <br>\r\n          <label id =\"label1\">Daily Production</label>\r\n      </ion-col>\r\n      <ion-col size=\"6\" id=\"column1\">\r\n         <a routerLink=\"/profit-loss\" ><ion-button color=\"light\" shape=\"round\" id =\"button\"><ion-icon name=\"add-circle\"></ion-icon></ion-button></a>\r\n          <br>\r\n          <label id =\"label1\">Profit And Loss</label>\r\n      </ion-col>\r\n    </ion-row>\r\n  <ion-row>\r\n    <br>\r\n    \r\n      \r\n      <ion-col size=\"6\" id=\"column1\">\r\n        <a routerLink=\"/stock-info\"  ><ion-button color=\"light\" shape=\"round\" id =\"button\"><ion-icon routerLink= \"stock-info\" name=\"add-circle\"></ion-icon></ion-button>\r\n          </a><br>\r\n          <label id =\"label1\" >Stock</label>\r\n        </ion-col>\r\n        <ion-col size=\"6\" id=\"column1\">\r\n            <ion-button color=\"light\" shape=\"round\" id =\"button\"><ion-icon name=\"add-circle\"></ion-icon></ion-button>\r\n            <br>\r\n            <label id =\"label1\">Attendance</label>\r\n        </ion-col>\r\n    </ion-row>\r\n    <br>\r\n    <ion-row>\r\n        <ion-col size=\"6\" id=\"column1\">\r\n            <ion-button color=\"light\" shape=\"round\" id =\"button\"><ion-icon name=\"add-circle\"></ion-icon></ion-button>\r\n            <br>\r\n            <label id =\"label1\">Other Expenses</label>\r\n        </ion-col>\r\n      </ion-row>\r\n\r\n</ion-content>\r\n"

/***/ }),

/***/ "./src/app/home/home.page.scss":
/*!*************************************!*\
  !*** ./src/app/home/home.page.scss ***!
  \*************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = "HEAD\n.body {\n  align-content: center; }\n\nion-content {\n  background-color: aqua; }\n\nion-avatar > img {\n  border-radius: 50%;\n  height: 150%;\n  width: 400%; }\n\n.title {\n  margin-top: 5%; }\n\n#button {\n  width: 80px;\n  height: 82px;\n  margin-left: 15px; }\n\n#column1 {\n  text-align: center; }\n\n#column {\n  text-align: center;\n  color: red;\n  font-size: 150%;\n  font-family: 'Gill Sans', 'Gill Sans MT', Calibri, 'Trebuchet MS', sans-serif; }\n\nhr {\n  height: 2px !important;\n  width: 500px !important;\n  background: black !important;\n  display: block !important;\n  font-size: 2em !important;\n  opacity: 1 !important;\n  visibility: visible !important; }\n\nion-icon {\n  font-size: 100px; }\n\n#label1 {\n  text-align: center;\n  color: red; }\n\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbInNyYy9hcHAvaG9tZS9DOlxcVXNlcnNcXEF2aW5hc2gga3VuZGFsXFxEZXNrdG9wXFxJbnZlbnRhcnkgaW9uaWMgYXBwXFxJbnZlbnRvcnkvc3JjXFxhcHBcXGhvbWVcXGhvbWUucGFnZS5zY3NzIl0sIm5hbWVzIjpbXSwibWFwcGluZ3MiOiJBQUFDOztFQUVHLHFCQUFxQixFQUFBOztBQUt6QjtFQUNJLHNCQUFzQixFQUFBOztBQUUxQjtFQUNJLGtCQUFpQjtFQUNqQixZQUFXO0VBQ1gsV0FBVSxFQUFBOztBQUVkO0VBQ0ksY0FBYyxFQUFBOztBQUVsQjtFQUNJLFdBQVc7RUFDWCxZQUFZO0VBQ2IsaUJBQWlCLEVBQUE7O0FBRXBCO0VBQ0ksa0JBQWtCLEVBQUE7O0FBRXRCO0VBQ0ksa0JBQWtCO0VBQ2xCLFVBQVU7RUFDVixlQUFlO0VBQ2YsNkVBQTZFLEVBQUE7O0FBRWpGO0VBQ0ksc0JBQXFCO0VBQ3JCLHVCQUFzQjtFQUN0Qiw0QkFBNEI7RUFDNUIseUJBQXlCO0VBQ3pCLHlCQUF5QjtFQUN6QixxQkFBb0I7RUFDcEIsOEJBQThCLEVBQUE7O0FBR2xDO0VBQ0ksZ0JBQWdCLEVBQUE7O0FBRXBCO0VBQ0ksa0JBQWtCO0VBQ2xCLFVBQVUsRUFBQSIsImZpbGUiOiJzcmMvYXBwL2hvbWUvaG9tZS5wYWdlLnNjc3MiLCJzb3VyY2VzQ29udGVudCI6WyIgSEVBRFxyXG4uYm9keXtcclxuICAgIGFsaWduLWNvbnRlbnQ6IGNlbnRlcjtcclxufVxyXG5cclxuI0RscHtcclxufVxyXG5pb24tY29udGVudHtcclxuICAgIGJhY2tncm91bmQtY29sb3I6IGFxdWE7XHJcbn1cclxuaW9uLWF2YXRhciA+IGltZ3tcclxuICAgIGJvcmRlci1yYWRpdXM6NTAlO1xyXG4gICAgaGVpZ2h0OjE1MCU7XHJcbiAgICB3aWR0aDo0MDAlO1xyXG59XHJcbi50aXRsZSB7XHJcbiAgICBtYXJnaW4tdG9wOiA1JTtcclxufVxyXG4jYnV0dG9ue1xyXG4gICAgd2lkdGg6IDgwcHg7XHJcbiAgICBoZWlnaHQ6IDgycHg7XHJcbiAgIG1hcmdpbi1sZWZ0OiAxNXB4O1xyXG59XHJcbiNjb2x1bW4xe1xyXG4gICAgdGV4dC1hbGlnbjogY2VudGVyO1xyXG59XHJcbiNjb2x1bW57XHJcbiAgICB0ZXh0LWFsaWduOiBjZW50ZXI7XHJcbiAgICBjb2xvcjogcmVkO1xyXG4gICAgZm9udC1zaXplOiAxNTAlO1xyXG4gICAgZm9udC1mYW1pbHk6ICdHaWxsIFNhbnMnLCAnR2lsbCBTYW5zIE1UJywgQ2FsaWJyaSwgJ1RyZWJ1Y2hldCBNUycsIHNhbnMtc2VyaWY7XHJcbn1cclxuaHJ7XHJcbiAgICBoZWlnaHQ6MnB4ICFpbXBvcnRhbnQ7XHJcbiAgICB3aWR0aDo1MDBweCAhaW1wb3J0YW50O1xyXG4gICAgYmFja2dyb3VuZDogYmxhY2sgIWltcG9ydGFudDtcclxuICAgIGRpc3BsYXk6IGJsb2NrICFpbXBvcnRhbnQ7XHJcbiAgICBmb250LXNpemU6IDJlbSAhaW1wb3J0YW50O1xyXG4gICAgb3BhY2l0eToxICFpbXBvcnRhbnQ7XHJcbiAgICB2aXNpYmlsaXR5OiB2aXNpYmxlICFpbXBvcnRhbnQ7XHJcblxyXG59XHJcbmlvbi1pY29ue1xyXG4gICAgZm9udC1zaXplOiAxMDBweDtcclxufVxyXG4jbGFiZWwxe1xyXG4gICAgdGV4dC1hbGlnbjogY2VudGVyO1xyXG4gICAgY29sb3I6IHJlZDtcclxufVxyXG4gXHJcbiJdfQ== */"

/***/ }),

/***/ "./src/app/home/home.page.ts":
/*!***********************************!*\
  !*** ./src/app/home/home.page.ts ***!
  \***********************************/
/*! exports provided: HomePage */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "HomePage", function() { return HomePage; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm5/core.js");


var HomePage = /** @class */ (function () {
    function HomePage() {
    }
    HomePage = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Component"])({
            selector: 'app-home',
            template: __webpack_require__(/*! ./home.page.html */ "./src/app/home/home.page.html"),
            styles: [__webpack_require__(/*! ./home.page.scss */ "./src/app/home/home.page.scss")]
        })
    ], HomePage);
    return HomePage;
}());



/***/ })

}]);
//# sourceMappingURL=home-home-module.js.map