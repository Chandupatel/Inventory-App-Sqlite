(window["webpackJsonp"] = window["webpackJsonp"] || []).push([["profit-loss-status-profit-loss-status-module"],{

/***/ "./src/app/profit-loss-status/profit-loss-status.module.ts":
/*!*****************************************************************!*\
  !*** ./src/app/profit-loss-status/profit-loss-status.module.ts ***!
  \*****************************************************************/
/*! exports provided: ProfitLossStatusPageModule */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "ProfitLossStatusPageModule", function() { return ProfitLossStatusPageModule; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm5/core.js");
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/common */ "./node_modules/@angular/common/fesm5/common.js");
/* harmony import */ var _angular_forms__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/forms */ "./node_modules/@angular/forms/fesm5/forms.js");
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @angular/router */ "./node_modules/@angular/router/fesm5/router.js");
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @ionic/angular */ "./node_modules/@ionic/angular/dist/fesm5.js");
/* harmony import */ var _profit_loss_status_page__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! ./profit-loss-status.page */ "./src/app/profit-loss-status/profit-loss-status.page.ts");







var routes = [
    {
        path: '',
        component: _profit_loss_status_page__WEBPACK_IMPORTED_MODULE_6__["ProfitLossStatusPage"]
    }
];
var ProfitLossStatusPageModule = /** @class */ (function () {
    function ProfitLossStatusPageModule() {
    }
    ProfitLossStatusPageModule = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["NgModule"])({
            imports: [
                _angular_common__WEBPACK_IMPORTED_MODULE_2__["CommonModule"],
                _angular_forms__WEBPACK_IMPORTED_MODULE_3__["FormsModule"],
                _ionic_angular__WEBPACK_IMPORTED_MODULE_5__["IonicModule"],
                _angular_router__WEBPACK_IMPORTED_MODULE_4__["RouterModule"].forChild(routes)
            ],
            declarations: [_profit_loss_status_page__WEBPACK_IMPORTED_MODULE_6__["ProfitLossStatusPage"]]
        })
    ], ProfitLossStatusPageModule);
    return ProfitLossStatusPageModule;
}());



/***/ }),

/***/ "./src/app/profit-loss-status/profit-loss-status.page.html":
/*!*****************************************************************!*\
  !*** ./src/app/profit-loss-status/profit-loss-status.page.html ***!
  \*****************************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = "<ion-header>\n \n    <ion-row>\n   <ion-title>For Profit and Loss</ion-title>\n   <!-- <ion-icon class=\"d\" name=\"contact\"></ion-icon> -->\n   <ion-icon class=\"d\" name=\"home\"></ion-icon>\n  </ion-row>\n   \n  \n  \n  </ion-header>\n\n  <ion-content>\n      <ion-card class = \"card1\">\n          <ion-item >\n           \n              <ion-label  slot=\"start\">Purchase Items</ion-label>\n              <ion-label  slot=\"end\">1</ion-label>\n            </ion-item>\n            <ion-item>\n                <ion-label  slot=\"start\">Total Cost</ion-label>\n                <ion-label  slot=\"end\">2</ion-label>\n            </ion-item>\n        </ion-card>\n        <ion-card class = \"card2\" >\n            <ion-item >\n           \n                <ion-label  slot=\"start\">Produced Items</ion-label>\n                <ion-label  slot=\"end\">1</ion-label>\n              </ion-item>\n              <ion-item>\n                  <ion-label  slot=\"start\">Total Cost</ion-label>\n                  <ion-label  slot=\"end\">2</ion-label>\n              </ion-item>\n          </ion-card>\n          <ion-card  class = \"card3\">\n              <ion-item >\n                  \n                  <ion-label  slot=\"start\">Other Expenses</ion-label>\n                \n                </ion-item>\n            </ion-card>\n            <ion-card class = \"card4\" >\n                <ion-item >\n               \n                    <ion-label  slot=\"start\">Sold Items</ion-label>\n                    <ion-label  slot=\"end\">1</ion-label>\n                  </ion-item>\n                  <ion-item>\n                      <ion-label  slot=\"start\">Total Cost</ion-label>\n                      <ion-label  slot=\"end\">2</ion-label>\n                  </ion-item>\n            </ion-card>\n                <button class=\"button button4\"><b>Profit</b><ion-icon class=\"b\" name=\"logo-usd\"></ion-icon>50<ion-icon class=\"c\" name=\"thumbs-up\"></ion-icon></button>\n                <button class=\"button1 button2\"><b>Loss</b><ion-icon class=\"e\" name=\"logo-usd\"></ion-icon>50<ion-icon class=\"f\" name=\"thumbs-down\"></ion-icon></button>\n  </ion-content>\n"

/***/ }),

/***/ "./src/app/profit-loss-status/profit-loss-status.page.scss":
/*!*****************************************************************!*\
  !*** ./src/app/profit-loss-status/profit-loss-status.page.scss ***!
  \*****************************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = ".but {\n  text-align: center;\n  border-color: #5fdf14;\n  border-radius: 125px;\n  width: 80%;\n  height: 10%;\n  margin-left: 10px; }\n\n.card1 {\n  border: 2px solid;\n  border-color: #1ba9cc;\n  border-radius: 25px;\n  margin-top: 20px; }\n\n.card2 {\n  border: 2px solid;\n  border-color: #a349d6;\n  border-radius: 25px; }\n\n.card3 {\n  border: 2px solid;\n  border-color: red;\n  border-radius: 25px;\n  height: 80px; }\n\n.card4 {\n  border: 2px solid;\n  border-color: #c7e908;\n  border-radius: 25px; }\n\n.card5 {\n  border: 2px solid;\n  border-color: green;\n  border-radius: 25px;\n  height: 80px; }\n\n.a {\n  font-size: 150%;\n  margin-right: 7%;\n  margin-top: 3%; }\n\n.b {\n  margin-left: 70px;\n  margin-right: 50px; }\n\n.c {\n  float: right; }\n\n.button {\n  margin-top: 10px;\n  background-color: lightgreen;\n  border: 2px solid;\n  color: white;\n  padding: 20px;\n  text-align: left;\n  text-decoration: none;\n  display: inline-block;\n  font-size: 16px;\n  width: 90%;\n  border-color: green;\n  margin-left: 20px; }\n\n.button4 {\n  border-radius: 18px; }\n\n.button1 {\n  margin-top: 10px;\n  background-color: #111411;\n  border: 2px solid;\n  color: white;\n  padding: 20px;\n  text-align: left;\n  text-decoration: none;\n  display: inline-block;\n  font-size: 16px;\n  width: 90%;\n  border-color: red;\n  margin-left: 20px; }\n\n.button2 {\n  border-radius: 18px; }\n\nion-title {\n  font-size: 120%;\n  color: #af2525;\n  margin-left: 18%;\n  margin-top: 2%; }\n\n.d {\n  font-size: 150%;\n  margin-right: 7%;\n  margin-top: 3%; }\n\n.e {\n  margin-left: 70px;\n  margin-right: 50px; }\n\n.f {\n  float: right; }\n\nion-header {\n  height: 8%; }\n\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbInNyYy9hcHAvcHJvZml0LWxvc3Mtc3RhdHVzL0M6XFxVc2Vyc1xcQXZpbmFzaCBrdW5kYWxcXERlc2t0b3BcXEludmVudGFyeSBpb25pYyBhcHBcXEludmVudG9yeS9zcmNcXGFwcFxccHJvZml0LWxvc3Mtc3RhdHVzXFxwcm9maXQtbG9zcy1zdGF0dXMucGFnZS5zY3NzIl0sIm5hbWVzIjpbXSwibWFwcGluZ3MiOiJBQUFBO0VBQ0ksa0JBQWtCO0VBQ2xCLHFCQUE2QjtFQUM3QixvQkFBb0I7RUFDcEIsVUFBUztFQUNULFdBQVU7RUFDVixpQkFBZ0IsRUFBQTs7QUFFcEI7RUFDSSxpQkFBa0I7RUFDbEIscUJBQThCO0VBQzlCLG1CQUFtQjtFQUNuQixnQkFBZSxFQUFBOztBQUVuQjtFQUNJLGlCQUFrQjtFQUNsQixxQkFBOEI7RUFDOUIsbUJBQW1CLEVBQUE7O0FBRXZCO0VBQ0ksaUJBQWtCO0VBQ2xCLGlCQUFnQjtFQUNoQixtQkFBbUI7RUFDbkIsWUFBVyxFQUFBOztBQUVkO0VBQ0csaUJBQWtCO0VBQ2xCLHFCQUE2QjtFQUM3QixtQkFBbUIsRUFBQTs7QUFFdEI7RUFDRyxpQkFBa0I7RUFDbEIsbUJBQWtCO0VBRWxCLG1CQUFtQjtFQUNuQixZQUFXLEVBQUE7O0FBSWY7RUFDSSxlQUFjO0VBQ2QsZ0JBQWU7RUFDZixjQUFhLEVBQUE7O0FBRWpCO0VBQ0EsaUJBQWlCO0VBQ2pCLGtCQUFpQixFQUFBOztBQUVqQjtFQUNHLFlBQVksRUFBQTs7QUFFZjtFQUNJLGdCQUFlO0VBQ2YsNEJBQTJCO0VBQzNCLGlCQUFpQjtFQUNqQixZQUFZO0VBQ1osYUFBYTtFQUNiLGdCQUFnQjtFQUNoQixxQkFBcUI7RUFDckIscUJBQXFCO0VBQ3JCLGVBQWU7RUFFZixVQUFTO0VBQ1QsbUJBQWtCO0VBQ2xCLGlCQUFnQixFQUFBOztBQUdsQjtFQUNJLG1CQUFrQixFQUFBOztBQUV4QjtFQUNJLGdCQUFlO0VBQ2YseUJBQWdDO0VBQ2hDLGlCQUFpQjtFQUNqQixZQUFZO0VBQ1osYUFBYTtFQUNiLGdCQUFnQjtFQUNoQixxQkFBcUI7RUFDckIscUJBQXFCO0VBQ3JCLGVBQWU7RUFFZixVQUFTO0VBQ1QsaUJBQWdCO0VBQ2hCLGlCQUFnQixFQUFBOztBQUdsQjtFQUNJLG1CQUFrQixFQUFBOztBQUV4QjtFQUNJLGVBQWU7RUFDZixjQUFzQjtFQUN0QixnQkFBZTtFQUVmLGNBQWEsRUFBQTs7QUFJakI7RUFDSSxlQUFjO0VBQ2QsZ0JBQWU7RUFDZixjQUFhLEVBQUE7O0FBRWpCO0VBQ0ksaUJBQWlCO0VBQ2pCLGtCQUFpQixFQUFBOztBQUVqQjtFQUNHLFlBQVksRUFBQTs7QUFHbEI7RUFDSSxVQUFTLEVBQUEiLCJmaWxlIjoic3JjL2FwcC9wcm9maXQtbG9zcy1zdGF0dXMvcHJvZml0LWxvc3Mtc3RhdHVzLnBhZ2Uuc2NzcyIsInNvdXJjZXNDb250ZW50IjpbIi5idXR7XHJcbiAgICB0ZXh0LWFsaWduOiBjZW50ZXI7XHJcbiAgICBib3JkZXItY29sb3I6cmdiKDk1LCAyMjMsIDIwKTtcclxuICAgIGJvcmRlci1yYWRpdXM6IDEyNXB4O1xyXG4gICAgd2lkdGg6ODAlO1xyXG4gICAgaGVpZ2h0OjEwJTtcclxuICAgIG1hcmdpbi1sZWZ0OjEwcHg7XHJcbn1cclxuLmNhcmQxIHtcclxuICAgIGJvcmRlcjogMnB4IHNvbGlkIDtcclxuICAgIGJvcmRlci1jb2xvcjpyZ2IoMjcsIDE2OSwgMjA0KTtcclxuICAgIGJvcmRlci1yYWRpdXM6IDI1cHg7XHJcbiAgICBtYXJnaW4tdG9wOjIwcHg7XHJcbiB9XHJcbi5jYXJkMiB7XHJcbiAgICBib3JkZXI6IDJweCBzb2xpZCA7XHJcbiAgICBib3JkZXItY29sb3I6cmdiKDE2MywgNzMsIDIxNCk7XHJcbiAgICBib3JkZXItcmFkaXVzOiAyNXB4O1xyXG4gfVxyXG4uY2FyZDMge1xyXG4gICAgYm9yZGVyOiAycHggc29saWQgO1xyXG4gICAgYm9yZGVyLWNvbG9yOnJlZDtcclxuICAgIGJvcmRlci1yYWRpdXM6IDI1cHg7XHJcbiAgICBoZWlnaHQ6ODBweDtcclxuIH1cclxuIC5jYXJkNCB7XHJcbiAgICBib3JkZXI6IDJweCBzb2xpZCA7XHJcbiAgICBib3JkZXItY29sb3I6cmdiKDE5OSwgMjMzLCA4KTtcclxuICAgIGJvcmRlci1yYWRpdXM6IDI1cHg7XHJcbiB9XHJcbiAuY2FyZDUge1xyXG4gICAgYm9yZGVyOiAycHggc29saWQgO1xyXG4gICAgYm9yZGVyLWNvbG9yOmdyZWVuO1xyXG4gICAgLy9iYWNrZ3JvdW5kLWNvbG9yOiBibHVlO1xyXG4gICAgYm9yZGVyLXJhZGl1czogMjVweDtcclxuICAgIGhlaWdodDo4MHB4O1xyXG4gICAgXHJcbiB9XHJcblxyXG4uYXtcclxuICAgIGZvbnQtc2l6ZToxNTAlO1xyXG4gICAgbWFyZ2luLXJpZ2h0OjclO1xyXG4gICAgbWFyZ2luLXRvcDozJTtcclxufVxyXG4uYntcclxubWFyZ2luLWxlZnQ6IDcwcHg7XHJcbm1hcmdpbi1yaWdodDo1MHB4O1xyXG59XHJcbi5je1xyXG4gICBmbG9hdDogcmlnaHQ7IFxyXG59XHJcbi5idXR0b24ge1xyXG4gICAgbWFyZ2luLXRvcDoxMHB4O1xyXG4gICAgYmFja2dyb3VuZC1jb2xvcjpsaWdodGdyZWVuO1xyXG4gICAgYm9yZGVyOiAycHggc29saWQ7XHJcbiAgICBjb2xvcjogd2hpdGU7XHJcbiAgICBwYWRkaW5nOiAyMHB4O1xyXG4gICAgdGV4dC1hbGlnbjogbGVmdDtcclxuICAgIHRleHQtZGVjb3JhdGlvbjogbm9uZTtcclxuICAgIGRpc3BsYXk6IGlubGluZS1ibG9jaztcclxuICAgIGZvbnQtc2l6ZTogMTZweDtcclxuICAgLy8gbWFyZ2luOiAxMHB4IDJweDtcclxuICAgIHdpZHRoOjkwJTtcclxuICAgIGJvcmRlci1jb2xvcjpncmVlbjtcclxuICAgIG1hcmdpbi1sZWZ0OjIwcHg7XHJcbiAgfVxyXG5cclxuICAuYnV0dG9uNCB7XHJcbiAgICAgIGJvcmRlci1yYWRpdXM6MThweDtcclxufVxyXG4uYnV0dG9uMXtcclxuICAgIG1hcmdpbi10b3A6MTBweDtcclxuICAgIGJhY2tncm91bmQtY29sb3I6cmdiKDE3LCAyMCwgMTcpO1xyXG4gICAgYm9yZGVyOiAycHggc29saWQ7XHJcbiAgICBjb2xvcjogd2hpdGU7XHJcbiAgICBwYWRkaW5nOiAyMHB4O1xyXG4gICAgdGV4dC1hbGlnbjogbGVmdDtcclxuICAgIHRleHQtZGVjb3JhdGlvbjogbm9uZTtcclxuICAgIGRpc3BsYXk6IGlubGluZS1ibG9jaztcclxuICAgIGZvbnQtc2l6ZTogMTZweDtcclxuICAgLy8gbWFyZ2luOiAxMHB4IDJweDtcclxuICAgIHdpZHRoOjkwJTtcclxuICAgIGJvcmRlci1jb2xvcjpyZWQ7XHJcbiAgICBtYXJnaW4tbGVmdDoyMHB4O1xyXG4gIH1cclxuXHJcbiAgLmJ1dHRvbjIge1xyXG4gICAgICBib3JkZXItcmFkaXVzOjE4cHg7XHJcbn1cclxuaW9uLXRpdGxle1xyXG4gICAgZm9udC1zaXplOiAxMjAlO1xyXG4gICAgY29sb3I6cmdiKDE3NSwgMzcsIDM3KTtcclxuICAgIG1hcmdpbi1sZWZ0OjE4JTtcclxuICAgLy8gZm9udC1mYW1pbHk6IGN1cnNpdmU7XHJcbiAgICBtYXJnaW4tdG9wOjIlO1xyXG4gICAgXHJcbiAgIFxyXG59XHJcbi5ke1xyXG4gICAgZm9udC1zaXplOjE1MCU7XHJcbiAgICBtYXJnaW4tcmlnaHQ6NyU7XHJcbiAgICBtYXJnaW4tdG9wOjMlO1xyXG59XHJcbi5le1xyXG4gICAgbWFyZ2luLWxlZnQ6IDcwcHg7XHJcbiAgICBtYXJnaW4tcmlnaHQ6NTBweDtcclxuICAgIH1cclxuICAgIC5me1xyXG4gICAgICAgZmxvYXQ6IHJpZ2h0OyBcclxuICAgIH1cclxuXHJcbiBpb24taGVhZGVye1xyXG4gICAgIGhlaWdodDo4JTtcclxuIH0iXX0= */"

/***/ }),

/***/ "./src/app/profit-loss-status/profit-loss-status.page.ts":
/*!***************************************************************!*\
  !*** ./src/app/profit-loss-status/profit-loss-status.page.ts ***!
  \***************************************************************/
/*! exports provided: ProfitLossStatusPage */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "ProfitLossStatusPage", function() { return ProfitLossStatusPage; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm5/core.js");


var ProfitLossStatusPage = /** @class */ (function () {
    function ProfitLossStatusPage() {
    }
    ProfitLossStatusPage.prototype.ngOnInit = function () {
    };
    ProfitLossStatusPage = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Component"])({
            selector: 'app-profit-loss-status',
            template: __webpack_require__(/*! ./profit-loss-status.page.html */ "./src/app/profit-loss-status/profit-loss-status.page.html"),
            styles: [__webpack_require__(/*! ./profit-loss-status.page.scss */ "./src/app/profit-loss-status/profit-loss-status.page.scss")]
        }),
        tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"]("design:paramtypes", [])
    ], ProfitLossStatusPage);
    return ProfitLossStatusPage;
}());



/***/ })

}]);
//# sourceMappingURL=profit-loss-status-profit-loss-status-module.js.map