(window["webpackJsonp"] = window["webpackJsonp"] || []).push([["purchaseitem-purchaseitem-module"],{

/***/ "./src/app/purchaseitem/purchaseitem.module.ts":
/*!*****************************************************!*\
  !*** ./src/app/purchaseitem/purchaseitem.module.ts ***!
  \*****************************************************/
/*! exports provided: PurchaseitemPageModule */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "PurchaseitemPageModule", function() { return PurchaseitemPageModule; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm5/core.js");
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/common */ "./node_modules/@angular/common/fesm5/common.js");
/* harmony import */ var _angular_forms__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/forms */ "./node_modules/@angular/forms/fesm5/forms.js");
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @angular/router */ "./node_modules/@angular/router/fesm5/router.js");
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @ionic/angular */ "./node_modules/@ionic/angular/dist/fesm5.js");
/* harmony import */ var _purchaseitem_page__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! ./purchaseitem.page */ "./src/app/purchaseitem/purchaseitem.page.ts");







var routes = [
    {
        path: '',
        component: _purchaseitem_page__WEBPACK_IMPORTED_MODULE_6__["PurchaseitemPage"]
    }
];
var PurchaseitemPageModule = /** @class */ (function () {
    function PurchaseitemPageModule() {
    }
    PurchaseitemPageModule = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["NgModule"])({
            imports: [
                _angular_common__WEBPACK_IMPORTED_MODULE_2__["CommonModule"],
                _angular_forms__WEBPACK_IMPORTED_MODULE_3__["FormsModule"],
                _ionic_angular__WEBPACK_IMPORTED_MODULE_5__["IonicModule"],
                _angular_router__WEBPACK_IMPORTED_MODULE_4__["RouterModule"].forChild(routes)
            ],
            declarations: [_purchaseitem_page__WEBPACK_IMPORTED_MODULE_6__["PurchaseitemPage"]]
        })
    ], PurchaseitemPageModule);
    return PurchaseitemPageModule;
}());



/***/ }),

/***/ "./src/app/purchaseitem/purchaseitem.page.html":
/*!*****************************************************!*\
  !*** ./src/app/purchaseitem/purchaseitem.page.html ***!
  \*****************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = "<ion-header>\r\n  <ion-toolbar>\r\n    <ion-title>Purchase Items List</ion-title>\r\n  </ion-toolbar>\r\n</ion-header>\r\n<ion-content>\r\n    <div class = \"but\">  \r\n        <ion-button color=\"danger\" shape=\"round\" >Purchase</ion-button>\r\n        &nbsp;&nbsp;&nbsp;\r\n            <ion-button  shape=\"round\" >Sale</ion-button>\r\n            </div>\r\n    <ion-card class = \"card1\">\r\n        <ion-item >\r\n            <!-- <ion-icon name=\"pin\" slot=\"start\"></ion-icon> -->\r\n            <ion-label  slot=\"start\">Product Name</ion-label>\r\n            &nbsp;&nbsp; &nbsp;&nbsp; &nbsp;&nbsp;&nbsp;&nbsp; &nbsp;&nbsp; &nbsp;&nbsp; &nbsp;&nbsp;  \r\n            <ion-icon name=\"create\"></ion-icon>\r\n                <ion-icon name=\"trash\"></ion-icon>\r\n            <!-- <ion-button fill=\"outline\" slot=\"end\">View</ion-button> -->\r\n          </ion-item>\r\n          <ion-item>\r\n              <ion-label  slot=\"start\">Quantity</ion-label>\r\n              <ion-label  slot=\"end\">Prize</ion-label>\r\n          </ion-item>\r\n      </ion-card>\r\n      <ion-card class = \"card2\" >\r\n          <ion-item >\r\n              <!-- <ion-icon name=\"pin\" slot=\"start\"></ion-icon> -->\r\n              <ion-label  slot=\"start\">Product Name</ion-label>\r\n              &nbsp;&nbsp; &nbsp;&nbsp; &nbsp;&nbsp;&nbsp;&nbsp; &nbsp;&nbsp; &nbsp;&nbsp; &nbsp;&nbsp;  \r\n              <ion-icon name=\"create\"></ion-icon>\r\n                <ion-icon name=\"trash\"></ion-icon>\r\n              <!-- <ion-button fill=\"outline\" slot=\"end\">View</ion-button> -->\r\n            </ion-item>\r\n            <ion-item>\r\n                <ion-label  slot=\"start\">Quantity</ion-label>\r\n                <ion-label  slot=\"end\">Prize</ion-label>\r\n            </ion-item>\r\n        </ion-card>\r\n        <ion-card class = \"card3\">\r\n            <ion-item >\r\n                <!-- <ion-icon name=\"pin\" slot=\"start\"></ion-icon> -->\r\n                <ion-label  slot=\"start\">Product Name</ion-label>\r\n                &nbsp;&nbsp; &nbsp;&nbsp; &nbsp;&nbsp; &nbsp;&nbsp; &nbsp;&nbsp;&nbsp;&nbsp; &nbsp;&nbsp;  \r\n                <ion-icon name=\"create\"></ion-icon>\r\n                <ion-icon name=\"trash\"></ion-icon>\r\n              </ion-item>\r\n              <ion-item>\r\n                  <ion-label  slot=\"start\">Quantity</ion-label>\r\n                  <ion-label  slot=\"end\">Prize</ion-label>\r\n              </ion-item>\r\n          </ion-card>\r\n          <ion-item>\r\n        <ion-icon name=\"add-circle\"></ion-icon>\r\n                &nbsp;&nbsp;   \r\n            <label>\r\n                  Add new Item\r\n              </label>\r\n          </ion-item>\r\n          \r\n                  <div class = \"but\">  \r\n                      <ion-button color=\"success\" shape=\"round\" >Summary</ion-button>\r\n                      </div>\r\n</ion-content>\r\n"

/***/ }),

/***/ "./src/app/purchaseitem/purchaseitem.page.scss":
/*!*****************************************************!*\
  !*** ./src/app/purchaseitem/purchaseitem.page.scss ***!
  \*****************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = ".but {\n  text-align: center;\n  margin-top: 20px; }\n\n.card1 {\n  border: 2px solid;\n  border-color: green;\n  border-radius: 25px;\n  margin-bottom: 20px; }\n\n.card2 {\n  border: 2px solid;\n  border-color: yellow;\n  border-radius: 25px;\n  margin-bottom: 20px; }\n\n.card3 {\n  border: 2px solid;\n  border-color: red;\n  border-radius: 25px;\n  margin-bottom: 20px; }\n\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbInNyYy9hcHAvcHVyY2hhc2VpdGVtL0M6XFxVc2Vyc1xcQXZpbmFzaCBrdW5kYWxcXERlc2t0b3BcXEludmVudGFyeSBpb25pYyBhcHBcXEludmVudG9yeS9zcmNcXGFwcFxccHVyY2hhc2VpdGVtXFxwdXJjaGFzZWl0ZW0ucGFnZS5zY3NzIl0sIm5hbWVzIjpbXSwibWFwcGluZ3MiOiJBQUFBO0VBQ0ksa0JBQWtCO0VBQ2xCLGdCQUFlLEVBQUE7O0FBRW5CO0VBQ0ksaUJBQWtCO0VBQ2xCLG1CQUFrQjtFQUNsQixtQkFBbUI7RUFDbkIsbUJBQW1CLEVBQUE7O0FBRXZCO0VBQ0ksaUJBQWtCO0VBQ2xCLG9CQUFtQjtFQUNuQixtQkFBbUI7RUFDbkIsbUJBQW1CLEVBQUE7O0FBRXZCO0VBQ0ksaUJBQWtCO0VBQ2xCLGlCQUFnQjtFQUNoQixtQkFBbUI7RUFDbkIsbUJBQW1CLEVBQUEiLCJmaWxlIjoic3JjL2FwcC9wdXJjaGFzZWl0ZW0vcHVyY2hhc2VpdGVtLnBhZ2Uuc2NzcyIsInNvdXJjZXNDb250ZW50IjpbIi5idXR7XHJcbiAgICB0ZXh0LWFsaWduOiBjZW50ZXI7XHJcbiAgICBtYXJnaW4tdG9wOjIwcHg7XHJcbn1cclxuLmNhcmQxIHtcclxuICAgIGJvcmRlcjogMnB4IHNvbGlkIDtcclxuICAgIGJvcmRlci1jb2xvcjpncmVlbjtcclxuICAgIGJvcmRlci1yYWRpdXM6IDI1cHg7XHJcbiAgICBtYXJnaW4tYm90dG9tOiAyMHB4O1xyXG4gfVxyXG4uY2FyZDIge1xyXG4gICAgYm9yZGVyOiAycHggc29saWQgO1xyXG4gICAgYm9yZGVyLWNvbG9yOnllbGxvdztcclxuICAgIGJvcmRlci1yYWRpdXM6IDI1cHg7XHJcbiAgICBtYXJnaW4tYm90dG9tOiAyMHB4O1xyXG4gfVxyXG4uY2FyZDMge1xyXG4gICAgYm9yZGVyOiAycHggc29saWQgO1xyXG4gICAgYm9yZGVyLWNvbG9yOnJlZDtcclxuICAgIGJvcmRlci1yYWRpdXM6IDI1cHg7XHJcbiAgICBtYXJnaW4tYm90dG9tOiAyMHB4O1xyXG4gfSJdfQ== */"

/***/ }),

/***/ "./src/app/purchaseitem/purchaseitem.page.ts":
/*!***************************************************!*\
  !*** ./src/app/purchaseitem/purchaseitem.page.ts ***!
  \***************************************************/
/*! exports provided: PurchaseitemPage */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "PurchaseitemPage", function() { return PurchaseitemPage; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm5/core.js");


var PurchaseitemPage = /** @class */ (function () {
    function PurchaseitemPage() {
    }
    PurchaseitemPage.prototype.ngOnInit = function () {
    };
    PurchaseitemPage = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Component"])({
            selector: 'app-purchaseitem',
            template: __webpack_require__(/*! ./purchaseitem.page.html */ "./src/app/purchaseitem/purchaseitem.page.html"),
            styles: [__webpack_require__(/*! ./purchaseitem.page.scss */ "./src/app/purchaseitem/purchaseitem.page.scss")]
        }),
        tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"]("design:paramtypes", [])
    ], PurchaseitemPage);
    return PurchaseitemPage;
}());



/***/ })

}]);
//# sourceMappingURL=purchaseitem-purchaseitem-module.js.map