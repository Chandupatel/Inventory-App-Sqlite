(window["webpackJsonp"] = window["webpackJsonp"] || []).push([["sold-item-summary-sold-item-summary-module"],{

/***/ "./src/app/sold-item-summary/sold-item-summary.module.ts":
/*!***************************************************************!*\
  !*** ./src/app/sold-item-summary/sold-item-summary.module.ts ***!
  \***************************************************************/
/*! exports provided: SoldItemSummaryPageModule */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "SoldItemSummaryPageModule", function() { return SoldItemSummaryPageModule; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm5/core.js");
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/common */ "./node_modules/@angular/common/fesm5/common.js");
/* harmony import */ var _angular_forms__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/forms */ "./node_modules/@angular/forms/fesm5/forms.js");
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @angular/router */ "./node_modules/@angular/router/fesm5/router.js");
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @ionic/angular */ "./node_modules/@ionic/angular/dist/fesm5.js");
/* harmony import */ var _sold_item_summary_page__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! ./sold-item-summary.page */ "./src/app/sold-item-summary/sold-item-summary.page.ts");







var routes = [
    {
        path: '',
        component: _sold_item_summary_page__WEBPACK_IMPORTED_MODULE_6__["SoldItemSummaryPage"]
    }
];
var SoldItemSummaryPageModule = /** @class */ (function () {
    function SoldItemSummaryPageModule() {
    }
    SoldItemSummaryPageModule = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["NgModule"])({
            imports: [
                _angular_common__WEBPACK_IMPORTED_MODULE_2__["CommonModule"],
                _angular_forms__WEBPACK_IMPORTED_MODULE_3__["FormsModule"],
                _ionic_angular__WEBPACK_IMPORTED_MODULE_5__["IonicModule"],
                _angular_router__WEBPACK_IMPORTED_MODULE_4__["RouterModule"].forChild(routes)
            ],
            declarations: [_sold_item_summary_page__WEBPACK_IMPORTED_MODULE_6__["SoldItemSummaryPage"]]
        })
    ], SoldItemSummaryPageModule);
    return SoldItemSummaryPageModule;
}());



/***/ }),

/***/ "./src/app/sold-item-summary/sold-item-summary.page.html":
/*!***************************************************************!*\
  !*** ./src/app/sold-item-summary/sold-item-summary.page.html ***!
  \***************************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = "<ion-header>\r\n  <ion-toolbar>\r\n    <ion-title>Sold_Item_Summary</ion-title>\r\n  </ion-toolbar>\r\n</ion-header>\r\n\r\n<ion-content>\r\n\r\n</ion-content>\r\n"

/***/ }),

/***/ "./src/app/sold-item-summary/sold-item-summary.page.scss":
/*!***************************************************************!*\
  !*** ./src/app/sold-item-summary/sold-item-summary.page.scss ***!
  \***************************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = "\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IiIsImZpbGUiOiJzcmMvYXBwL3NvbGQtaXRlbS1zdW1tYXJ5L3NvbGQtaXRlbS1zdW1tYXJ5LnBhZ2Uuc2NzcyJ9 */"

/***/ }),

/***/ "./src/app/sold-item-summary/sold-item-summary.page.ts":
/*!*************************************************************!*\
  !*** ./src/app/sold-item-summary/sold-item-summary.page.ts ***!
  \*************************************************************/
/*! exports provided: SoldItemSummaryPage */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "SoldItemSummaryPage", function() { return SoldItemSummaryPage; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm5/core.js");


var SoldItemSummaryPage = /** @class */ (function () {
    function SoldItemSummaryPage() {
    }
    SoldItemSummaryPage.prototype.ngOnInit = function () {
    };
    SoldItemSummaryPage = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Component"])({
            selector: 'app-sold-item-summary',
            template: __webpack_require__(/*! ./sold-item-summary.page.html */ "./src/app/sold-item-summary/sold-item-summary.page.html"),
            styles: [__webpack_require__(/*! ./sold-item-summary.page.scss */ "./src/app/sold-item-summary/sold-item-summary.page.scss")]
        }),
        tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"]("design:paramtypes", [])
    ], SoldItemSummaryPage);
    return SoldItemSummaryPage;
}());



/***/ })

}]);
//# sourceMappingURL=sold-item-summary-sold-item-summary-module.js.map