(window["webpackJsonp"] = window["webpackJsonp"] || []).push([["add-sold-item-add-sold-item-module"],{

/***/ "./src/app/add-sold-item/add-sold-item.module.ts":
/*!*******************************************************!*\
  !*** ./src/app/add-sold-item/add-sold-item.module.ts ***!
  \*******************************************************/
/*! exports provided: AddSoldItemPageModule */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "AddSoldItemPageModule", function() { return AddSoldItemPageModule; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm5/core.js");
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/common */ "./node_modules/@angular/common/fesm5/common.js");
/* harmony import */ var _angular_forms__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/forms */ "./node_modules/@angular/forms/fesm5/forms.js");
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @angular/router */ "./node_modules/@angular/router/fesm5/router.js");
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @ionic/angular */ "./node_modules/@ionic/angular/dist/fesm5.js");
/* harmony import */ var _add_sold_item_page__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! ./add-sold-item.page */ "./src/app/add-sold-item/add-sold-item.page.ts");







var routes = [
    {
        path: '',
        component: _add_sold_item_page__WEBPACK_IMPORTED_MODULE_6__["AddSoldItemPage"]
    }
];
var AddSoldItemPageModule = /** @class */ (function () {
    function AddSoldItemPageModule() {
    }
    AddSoldItemPageModule = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["NgModule"])({
            imports: [
                _angular_common__WEBPACK_IMPORTED_MODULE_2__["CommonModule"],
                _angular_forms__WEBPACK_IMPORTED_MODULE_3__["FormsModule"],
                _ionic_angular__WEBPACK_IMPORTED_MODULE_5__["IonicModule"],
                _angular_router__WEBPACK_IMPORTED_MODULE_4__["RouterModule"].forChild(routes)
            ],
            declarations: [_add_sold_item_page__WEBPACK_IMPORTED_MODULE_6__["AddSoldItemPage"]]
        })
    ], AddSoldItemPageModule);
    return AddSoldItemPageModule;
}());



/***/ }),

/***/ "./src/app/add-sold-item/add-sold-item.page.html":
/*!*******************************************************!*\
  !*** ./src/app/add-sold-item/add-sold-item.page.html ***!
  \*******************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = "<ion-header>\r\n  <ion-toolbar>\r\n    <ion-title>Add_Sold_Item</ion-title>\r\n  </ion-toolbar>\r\n</ion-header>\r\n\r\n<ion-content>\r\n    <ion-item>\r\n  \r\n        <ion-input type =\"text\" placeholder=\"Product Name\"></ion-input>\r\n      </ion-item>\r\n      <ion-item>\r\n          \r\n          <ion-input type =\"text\" placeholder=\"Customer Name\"></ion-input>\r\n      </ion-item>\r\n          <ion-item>\r\n            <ion-row>\r\n              <ion-col>\r\n             \r\n              <ion-input type =\"number\" placeholder=\"Quantity\"></ion-input>\r\n            </ion-col>\r\n            <ion-col>\r\n                \r\n                <ion-select placeholder=\"Unit\" value=\"Unit\">\r\n                  <ion-select-option >Kilogram</ion-select-option>\r\n                  <ion-select-option >gram</ion-select-option>\r\n                </ion-select>\r\n             \r\n            </ion-col>\r\n            </ion-row>\r\n            </ion-item>\r\n            <ion-item>\r\n                \r\n                <ion-input type =\"number\" placeholder=\"Total Amount\"></ion-input>\r\n              </ion-item>\r\n              <ion-item>\r\n                 \r\n                  <ion-input type =\"number\" placeholder=\"Paid Amount\"></ion-input>\r\n                </ion-item>\r\n                <ion-item>\r\n                  <ion-row>\r\n                          <ion-col>\r\n                      <input type=\"checkbox\"  name=\"payment\" checked>&nbsp;Full Payment\r\n                      &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;\r\n                      <input type=\"checkbox\"  name=\"payment\" checked>Partial Payment\r\n                      </ion-col>\r\n                  </ion-row>\r\n                </ion-item>\r\n                 <ion-item>\r\n                   <ion-col>\r\n                   <input type=\"checkbox\"  name=\"payment\" > Pending Payment\r\n                  </ion-col>\r\n                  </ion-item>\r\n                     \r\n                <ion-item>\r\n                    \r\n                    <ion-input type =\"number\" placeholder=\"Date of Purchase\"></ion-input>\r\n                  </ion-item>\r\n                  <ion-item>\r\n                      \r\n                      <ion-textarea placeholder=\"Enter the details here...\"></ion-textarea>\r\n                    </ion-item>\r\n                    \r\n                  <ion-item>\r\n                      <ion-button color=\"danger\" shape=\"round\" >Save</ion-button>\r\n                  </ion-item>\r\n               \r\n                  <ion-item>\r\n\r\n                  \r\n              <ion-button color=\"danger\" shape=\"round\" >Purchase</ion-button>\r\n                  <ion-button  shape=\"round\" >Sale</ion-button>\r\n                </ion-item>\r\n</ion-content>\r\n"

/***/ }),

/***/ "./src/app/add-sold-item/add-sold-item.page.scss":
/*!*******************************************************!*\
  !*** ./src/app/add-sold-item/add-sold-item.page.scss ***!
  \*******************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = "ion-input {\n  border: 1px solid gray; }\n\nion-select {\n  border: 1px solid gray; }\n\nion-title {\n  color: red; }\n\nion-textarea {\n  border: 1px solid gray; }\n\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbInNyYy9hcHAvYWRkLXNvbGQtaXRlbS9DOlxcVXNlcnNcXEF2aW5hc2gga3VuZGFsXFxEZXNrdG9wXFxJbnZlbnRhcnkgaW9uaWMgYXBwXFxJbnZlbnRvcnkvc3JjXFxhcHBcXGFkZC1zb2xkLWl0ZW1cXGFkZC1zb2xkLWl0ZW0ucGFnZS5zY3NzIl0sIm5hbWVzIjpbXSwibWFwcGluZ3MiOiJBQUFBO0VBQ0ksc0JBQXNCLEVBQUE7O0FBUXRCO0VBQ0ksc0JBQXNCLEVBQUE7O0FBRTFCO0VBQ0ksVUFBUyxFQUFBOztBQUdiO0VBQ0ksc0JBQXNCLEVBQUEiLCJmaWxlIjoic3JjL2FwcC9hZGQtc29sZC1pdGVtL2FkZC1zb2xkLWl0ZW0ucGFnZS5zY3NzIiwic291cmNlc0NvbnRlbnQiOlsiaW9uLWlucHV0e1xyXG4gICAgYm9yZGVyOiAxcHggc29saWQgZ3JheTsgICBcclxuICAgIH1cclxuICAgIC8vIC5idXQxe1xyXG4gICAgLy8gICAgIHRleHQtYWxpZ246IGNlbnRlcjtcclxuICAgIC8vICAgICBtYXJnaW4tbGVmdDogMzUlO1xyXG4gICAgLy8gICAgIGJsb2NrLXNpemU6IDMwJTtcclxuICAgIC8vIH1cclxuICAgIFxyXG4gICAgaW9uLXNlbGVjdHtcclxuICAgICAgICBib3JkZXI6IDFweCBzb2xpZCBncmF5OyAgIFxyXG4gICAgICAgIH1cclxuICAgIGlvbi10aXRsZXtcclxuICAgICAgICBjb2xvcjpyZWQ7XHJcbiAgICAgICAgXHJcbiAgICB9ICAgXHJcbiAgICBpb24tdGV4dGFyZWF7XHJcbiAgICAgICAgYm9yZGVyOiAxcHggc29saWQgZ3JheTsgXHJcbiAgICB9IFxyXG4gICAgIl19 */"

/***/ }),

/***/ "./src/app/add-sold-item/add-sold-item.page.ts":
/*!*****************************************************!*\
  !*** ./src/app/add-sold-item/add-sold-item.page.ts ***!
  \*****************************************************/
/*! exports provided: AddSoldItemPage */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "AddSoldItemPage", function() { return AddSoldItemPage; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm5/core.js");


var AddSoldItemPage = /** @class */ (function () {
    function AddSoldItemPage() {
    }
    AddSoldItemPage.prototype.ngOnInit = function () {
    };
    AddSoldItemPage = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Component"])({
            selector: 'app-add-sold-item',
            template: __webpack_require__(/*! ./add-sold-item.page.html */ "./src/app/add-sold-item/add-sold-item.page.html"),
            styles: [__webpack_require__(/*! ./add-sold-item.page.scss */ "./src/app/add-sold-item/add-sold-item.page.scss")]
        }),
        tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"]("design:paramtypes", [])
    ], AddSoldItemPage);
    return AddSoldItemPage;
}());



/***/ })

}]);
//# sourceMappingURL=add-sold-item-add-sold-item-module.js.map